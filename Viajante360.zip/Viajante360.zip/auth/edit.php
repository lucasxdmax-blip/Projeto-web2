<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'Método não permitido']);
    exit;
}

if (empty($_SESSION['user']['id'])) {
    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'Usuário não autenticado.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$name  = trim($input['name'] ?? '');
$email = trim($input['email'] ?? '');
$pass  = $input['password'] ?? '';

if ($name === '' || $email === '') {
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Nome e email são obrigatórios.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Email inválido.']);
    exit;
}

$userId = (int) $_SESSION['user']['id'];

try {
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1');
    $stmt->execute([$email, $userId]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['success'=>false,'message'=>'Email já em uso por outro usuário.']);
        exit;
    }

    $fields = ['name = ?','email = ?'];
    $params = [$name, $email];

    if ($pass !== '' && $pass !== null) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $fields[] = 'password_hash = ?';
        $params[] = $hash;
    }

    $params[] = $userId;

    $sql = 'UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $stmt = $pdo->prepare('SELECT id, name, email FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    $_SESSION['user'] = $user;

    echo json_encode(['success'=>true,'message'=>'Perfil atualizado','user'=>$user]);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    @file_put_contents(__DIR__ . '/debug.log', '['.date('c')."] edit error: ".$e->getMessage()."\n", FILE_APPEND);
    echo json_encode(['success'=>false,'message'=>'Erro interno no servidor.']);
    exit;
}
