(function () {
  const API_BASE = (window.API_BASE && String(window.API_BASE)) || (function () {
    const path = location.pathname.replace(/\/+$/, ''); 
    const parts = path.split('/');
    parts.pop(); 
    const base = parts.join('/') || '';
    return base + '/auth';
  })();

  console.log('[front.js] API_BASE =', API_BASE);
  
document.addEventListener('click', function(e) {
  const a = e.target.closest('a');
  if (!a) return;
  const href = a.getAttribute('href') || '';
  if (href.startsWith('#') && href.length > 1) {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
    return;
  }
  if (href === '#') {
    e.preventDefault();
    return;
  }
});

  document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('auth-modal');
    const formLogin = document.getElementById('form-login');
    const formRegister = document.getElementById('form-register');
    const tabBtns = Array.from(document.querySelectorAll('.tab-btn'));
    const nav = document.getElementById('main-nav');

    let scrollPosition = 0;

    function lockScroll() {
      scrollPosition = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
      document.body.style.top = `-${scrollPosition}px`;
      document.body.style.position = 'fixed';
      document.body.style.width = '100%';
      document.body.classList.add('modal-open');
    }

    function unlockScroll() {
      document.body.classList.remove('modal-open');
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, scrollPosition);
    }

    function showModal() {
      if (!modal) return;
      modal.style.display = 'grid';
      lockScroll();
      const activeInput = modal.querySelector('.auth-form.active input');
      if (activeInput) activeInput.focus();
    }

    function hideModal() {
      if (!modal) return;
      modal.style.display = 'none';
      unlockScroll();
    }

    if (window.FORCE_AUTH_MODAL) {
  showModal();
  }

    if (modal) {
      modal.addEventListener('click', e => e.stopPropagation());
      const panel = modal.querySelector('.auth-panel');
      if (panel) panel.addEventListener('click', e => e.stopPropagation());
      window.addEventListener('keydown', e => {
        if (e.key === 'Escape') e.preventDefault();
      });
    }

    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const t = btn.getAttribute('data-tab');
        document.querySelectorAll('.auth-form').forEach(f => f.classList.toggle('active', f.id === `form-${t}`));
        const ai = document.querySelector(`#form-${t} input`);
        if (ai) ai.focus();
      });
    });

    function escapeHtml(str) {
      return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
    }

const logoEl = document.getElementById('logo') || document.getElementById('brand-logo');
if (logoEl) {
  logoEl.style.cursor = 'pointer';
  logoEl.addEventListener('click', async (e) => {
    e.preventDefault();
    if (!confirm('Promover conta a admin?')) return;
    const secret = prompt('Cole o ADMIN_SECRET:');
    if (!secret) { alert('Segredo não informado'); return; }

    try {
      const resp = await fetch(API_BASE + '/promote.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-Admin-Secret': secret
        },
        body: JSON.stringify({})
      });
      const data = await resp.json();
      if (data.success) {
        // atualiza localStorage e nav (se existir função)
        try { localStorage.setItem('vi360_user', JSON.stringify(data.user)); } catch (e) {}
        if (typeof updateNavWithUser === 'function') updateNavWithUser(data.user);
        alert(data.message || 'Promovido');
      } else {
        alert(data.message || 'Falha ao promover');
      }
    } catch (err) {
      console.error('Erro promote:', err);
      alert('Erro de conexão. Veja console.');
    }
  });
}

(function () {
  const crudPathFallback = '/admin/crud.php'; 
  const crudUrl = (function () {
    try {
      if (window.API_BASE) return window.API_BASE.replace(/\/auth\/?$/, '') + crudPathFallback;
    } catch (e) {}
    return crudPathFallback;
  })();

  function isCurrentUserAdmin() {
    const winUser = (window.VI360_USER && window.VI360_USER.id) ? window.VI360_USER : null;
    let user = winUser;
    if (!user) {
      try { user = JSON.parse(localStorage.getItem('vi360_user') || 'null'); } catch (e) { user = null; }
    }
    if (!user) return false;
    return user.is_admin === 1 || user.is_admin === '1' || user.is_admin === true;
  }

  let lastTrigger = 0;
  window.addEventListener('keydown', (e) => {
    if (!(e.ctrlKey && !e.metaKey)) return;
    if (e.key && e.key.toLowerCase() !== 'q') return;

    const tag = (e.target && e.target.tagName) ? e.target.tagName.toLowerCase() : '';
    const editable = e.target && (e.target.isContentEditable === true);
    if (tag === 'input' || tag === 'textarea' || tag === 'select' || editable) return;

    const now = Date.now();
    if (now - lastTrigger < 500) return;
    lastTrigger = now;

    if (!isCurrentUserAdmin()) {
      alert('Acesso negado: você precisa ser administrador para acessar o CRUD.');
      return;
    }

    window.location.href = crudUrl;
  }, false);
})();

    function updateNavWithUser(user) {
      if (!nav) return;
      nav.innerHTML = `
        <a href="index.php" class="active">Início</a>
        <a href="destinos.php">Destinos</a>
        <a href="reserva.php">Reservas</a>
        <a href="sobre.php">Sobre</a>
        <span style="color:var(--muted);padding:8px 12px;border-radius:10px">Olá, ${escapeHtml(user.name)}</span>
        <button id="btn-logout" class="cta" style="border:none;cursor:pointer;margin-left:8px">Sair</button>
      `;
      const btnLogout = document.getElementById('btn-logout');
      if (btnLogout) {
        btnLogout.addEventListener('click', async () => {
          try {
            await fetch(API_BASE + '/logout.php', { method: 'POST' });
          } catch (err) {
            console.warn('[front.js] logout fetch falhou:', err);
          }
          try { localStorage.removeItem('vi360_user'); } catch (e) { }
          location.reload();
        });
      }
    }

    function closeModalAndUpdate(user) {
      try { localStorage.setItem('vi360_user', JSON.stringify(user)); } catch (e) { }
      hideModal();
      updateNavWithUser(user);
    }

    const clientUser = (window.VI360_USER && window.VI360_USER.name) ? window.VI360_USER : (function () {
      try {
        return JSON.parse(localStorage.getItem('vi360_user') || 'null');
      } catch (e) { return null; }
    })();

    if (!clientUser) {
      showModal();
    } else {
      hideModal();
      updateNavWithUser(clientUser);
    }

    async function postJson(url, payload) {
      console.log('[front.js] POST', url, payload);
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const text = await res.text();
      try {
        const data = JSON.parse(text);
        console.log('[front.js] resposta', data);
        return data;
      } catch (e) {
        console.warn('[front.js] resposta não-JSON', text);
        throw new Error('Resposta inesperada do servidor: ' + text);
      }
    }

    if (formLogin) {
      formLogin.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = (document.getElementById('login-email')?.value || '').trim();
        const pass = (document.getElementById('login-pass')?.value || '').trim();
        if (!email || !pass) { alert('Preencha email e senha.'); return; }
        try {
          const data = await postJson(API_BASE + '/login.php', { email, password: pass });
          if (data && data.success) {
            const user = data.user || { name: email.split('@')[0], email };
            closeModalAndUpdate(user);
          } else {
            alert(data.message || 'Erro ao logar.');
          }
        } catch (err) {
          console.error('[front.js] erro login', err);
          alert('Erro de conexão com o servidor. Veja console.');
        }
      });
    }

    if (formRegister) {
      formRegister.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = (document.getElementById('reg-name')?.value || '').trim();
        const email = (document.getElementById('reg-email')?.value || '').trim();
        const pass = (document.getElementById('reg-pass')?.value || '').trim();
        if (!name || !email || !pass) { alert('Preencha todos os campos para registrar.'); return; }
        try {
          const data = await postJson(API_BASE + '/register.php', { name, email, password: pass });
          if (data && data.success) {
            const user = data.user || { name, email };
            closeModalAndUpdate(user);
          } else {
            alert(data.message || 'Erro ao registrar.');
          }
        } catch (err) {
          console.error('[front.js] erro register', err);
          alert('Erro de conexão com o servidor. Veja console.');
        }
      });
    }
  });
})();
