<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/destinos_api/token_csrf.php';
$user = $_SESSION['user'] ?? null;

$baseUrl = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$apiBase = $baseUrl . '/auth';

$csrf = generate_csrf_token();
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Destinos — Viajante 360</title>
  <link rel="shortcut icon" href="image/logo.png" type="image/x-icon">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/destinos.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@300;400;600&display=swap"
    rel="stylesheet">
  <script>
    window.VI360_USER = <?= json_encode($user, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
    window.API_BASE = "<?= htmlspecialchars($apiBase, ENT_QUOTES) ?>";
  </script>
</head>
<body>
  <header class="site-header">
    <div class="brand">
      <img src="image/logo.png" alt="Viajante 360" class="logo" id="brand-logo">
      <div>
        <h1>Viajante 360</h1>
        <p>Viagens com atitude</p>
      </div>
    <nav id="main-nav" class="main-nav" aria-label="Navegação principal">
      <a href="index.php">Início</a>
      <a href="destinos.php" class="active">Destinos</a>
      <a href="reserva.php">Reservas</a>
      <a href="sobre.php">Sobre</a>
      <a class="cta" href="#reservar">User</a>
    </nav>
   </div>
  </header>

  <main class="container main-content">
    <section class="header-top">
      <div>
        <h1>Destinos</h1>
        <p class="muted" id="admin_info">Adicione, edite ou remova destinos do catálogo.</p>
      </div>
      <div>
        <button id="btn-novo" class="btn-new">+ Novo destino</button>
      </div>
    </section>

    <section class="filters-row" aria-label="Filtros de busca" style="margin:18px 0;">
      <div class="filters-left">
        <input id="searchText" class="filter-input" type="search" placeholder="Pesquisar" aria-label="Pesquisar">
        <select id="filterCountry" class="filter-select" aria-label="Filtrar por local">
          <option value="">Todos os locais</option>
        </select>

        <label class="filter-price" style="display:flex;align-items:center;gap:6px;">
          <input id="priceMin" type="number" placeholder="Preço mín" min="0" step="0.01" style="width:110px">
          <span></span>
          <input id="priceMax" type="number" placeholder="Preço máx" min="0" step="0.01" style="width:110px">
        </label>

        <button id="btnFilterReset" class="btn-clear">Limpar</button>
      </div>

      <div class="filters-right">
        <label>
          Itens por página
          <select id="perPage" class="filter-select" aria-label="Itens por página">
            <option value="6" selected>6</option>
            <option value="9">9</option>
            <option value="12">12</option>
          </select>
        </label>
      </div>
    </section>

    <section id="lista-destinos" aria-live="polite" class="list-grid" role="list"></section>

    <nav id="pagination" class="pagination" aria-label="Paginação de resultados" style="margin-top:18px;display:flex;justify-content:center"></nav>

  </main>

  <div id="form-container" aria-hidden="true">
    <div class="panel" role="dialog" aria-modal="true" aria-labelledby="form-title">
      <form id="destino-form" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="id" id="dest-id" value="">
        <h2 id="form-title">Salvar destino</h2>

        <label>
          Título
          <input type="text" name="titulo" id="titulo" placeholder="Ex.: Praia do Sol" required>
        </label>

        <label>
          Descrição
          <textarea name="descricao" id="descricao" placeholder="Descrição do destino" required></textarea>
        </label>

        <div class="row">
          <label>
            Preço (R$)
            <input type="text" name="preco" id="preco" placeholder="Ex.: 1299.00">
          </label>
          <label>
            Localização
            <input type="text" name="localizacao" id="localizacao" placeholder="Cidade / Estado">
          </label>
        </div>

        <label>
          Imagem (JPEG / PNG / WEBP) — max 4MB
          <input type="file" name="imagem" id="imagem" accept="image/jpeg,image/png,image/webp">
        </label>

        <div class="form-actions">
          <label class="chk-available">
            <input type="checkbox" name="disponivel" id="disponivel" value="1" checked>
            Disponível
          </label>
          <div class="btn-group">
            <button type="submit" id="submit-btn">Salvar</button>
            <button type="button" id="cancel-btn">Cancelar</button>
          </div>
        </div>

        <div id="preview" class="preview"></div>
        <div id="msg-area" class="msg-area"></div>
      </form>
    </div>
  </div>

  <div id="auth-modal" class="auth-modal" aria-hidden="true" role="dialog" aria-modal="true">
    <div class="auth-panel">
      <div class="auth-header">
        <img src="image/logo.png" alt="Viajante 360" class="auth-logo">
        <div>
          <h2>Bem-vindo ao Viajante 360</h2>
          <p>Crie sua conta ou entre para desbloquear o acesso.</p>
        </div>
      </div>
      <div class="auth-tabs">
        <button type="button" class="tab-btn active" data-tab="login">Entrar</button>
        <button type="button" class="tab-btn" data-tab="register">Registrar</button>
      </div>
      <div class="auth-body">
        <form id="form-login" class="auth-form active" autocomplete="off">
          <label>Email</label>
          <input type="email" id="login-email" required placeholder="seu@exemplo.com">
          <label>Senha</label>
          <input type="password" id="login-pass" required placeholder="********">
          <button type="submit" class="btn-auth">Entrar</button>
        </form>
        <form id="form-register" class="auth-form" autocomplete="off">
          <label>Nome</label>
          <input type="text" id="reg-name" required placeholder="Seu nome">
          <label>Email</label>
          <input type="email" id="reg-email" required placeholder="seu@exemplo.com">
          <label>Senha</label>
          <input type="password" id="reg-pass" required placeholder="********">
          <button type="submit" class="btn-auth">Registrar</button>
        </form>
      </div>
      <div class="auth-footer">
        <small>É obrigatório — você só poderá navegar após registrar-se ou entrar.</small>
      </div>
    </div>
  </div>
  <footer>
      <div>© <strong>Mígrasoft</strong> · 2025</div>
        <div class="social">
          <a href="#" title="Instagram">IG</a>
          <a href="#" title="Twitter">TW</a>
          <a href="#" title="Contato">📱</a>
      </div>
  </footer>
  <script>
    window.FORCE_AUTH_MODAL = <?= (isset($_GET['logged_out']) && $_GET['logged_out'] == '1') ? 'true' : 'false' ?>;
  </script>
  <script src="js/destinos.js"></script>
</body>
</html>
