<?php

session_start();
header('Content-Type: text/html; charset=utf-8');

$dbHost = '127.0.0.1';
$dbUser = 'root';
$dbPass = '';
$dbName = 'viajante360';

$user = $_SESSION['user'] ?? null;
if (!$user || !isset($user['is_admin']) || ($user['is_admin'] != 1 && $user['is_admin'] !== true)) {
    header('HTTP/1.1 403 Forbidden');
    echo "<h1>403 — Acesso negado</h1><p>Você precisa ser administrador para acessar esta página.</p>";
    exit;
}

$mysqli = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
if ($mysqli->connect_errno) {
    http_response_code(500);
    echo "<h1>Erro de conexão</h1><p>Erro DB: " . htmlspecialchars($mysqli->connect_error) . "</p>";
    exit;
}
$mysqli->set_charset('utf8mb4');

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
$CSRF = $_SESSION['csrf_token'];

function h($v) { return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

$action = $_POST['action'] ?? null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action) {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], (string)$token)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'CSRF inválido']);
        exit;
    }

    if ($action === 'create') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pass = trim($_POST['password'] ?? '');
        $is_admin = isset($_POST['is_admin']) ? 1 : 0;

        if ($name === '' || $email === '' || $pass === '') {
            $err = 'Preencha nome, email e senha.';
        } else {
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $stmt = $mysqli->prepare("INSERT INTO users (name, email, password_hash, is_admin, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->bind_param('sssi', $name, $email, $hash, $is_admin);
            if ($stmt->execute()) {
                header('Location: crud.php?msg=' . urlencode('Usuário criado com sucesso'));
                exit;
            } else {
                $err = 'Erro ao criar: ' . $mysqli->error;
            }
        }
    }

    if ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $is_admin = isset($_POST['is_admin']) ? 1 : 0;
        $pass = trim($_POST['password'] ?? '');

        if ($id <= 0 || $name === '' || $email === '') {
            $err = 'ID inválido ou campos vazios.';
        } else {
            if ($pass !== '') {
                $hash = password_hash($pass, PASSWORD_BCRYPT);
                $stmt = $mysqli->prepare("UPDATE users SET name = ?, email = ?, password_hash = ?, is_admin = ? WHERE id = ?");
                $stmt->bind_param('sssii', $name, $email, $hash, $is_admin, $id);
            } else {
                $stmt = $mysqli->prepare("UPDATE users SET name = ?, email = ?, is_admin = ? WHERE id = ?");
                $stmt->bind_param('ssii', $name, $email, $is_admin, $id);
            }
            if ($stmt->execute()) {
                header('Location: crud.php?msg=' . urlencode('Usuário atualizado'));
                exit;
            } else {
                $err = 'Erro ao atualizar: ' . $mysqli->error;
            }
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $err = 'ID inválido.';
        } else {
            $stmt = $mysqli->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param('i', $id);
            if ($stmt->execute()) {
                header('Location: crud.php?msg=' . urlencode('Usuário apagado'));
                exit;
            } else {
                $err = 'Erro ao apagar: ' . $mysqli->error;
            }
        }
    }
}

$result = $mysqli->query("SELECT id, name, email, is_admin, created_at FROM users ORDER BY id DESC LIMIT 500");
$users = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $result->free();
}

$editing = null;
if (isset($_GET['edit_id'])) {
    $eid = (int)$_GET['edit_id'];
    if ($eid > 0) {
        $q = $mysqli->prepare("SELECT id, name, email, is_admin FROM users WHERE id = ?");
        $q->bind_param('i', $eid);
        $q->execute();
        $editing = $q->get_result()->fetch_assoc();
    }
}

$msg = isset($_GET['msg']) ? $_GET['msg'] : null;
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <link rel="shortcut icon" href="image/logo.png" type="image/x-icon">
  <title>Admin CRUD — Viajante 360</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <style>
    body{font-family:Inter,Arial,Helvetica,sans-serif;padding:18px;background:#f6f7fb;color:#111}
    h1{margin:0 0 12px}
    .wrap{max-width:1100px;margin:0 auto}
    table{width:100%;border-collapse:collapse;background:#fff}
    th,td{padding:10px;border-bottom:1px solid #eee;text-align:left}
    th{background:#fafafa}
    form.inline{display:inline}
    .card{background:#fff;padding:12px;border-radius:8px;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,0.04)}
    .danger{color:#b00}
    .btn{display:inline-block;padding:8px 12px;border-radius:6px;border:0;background:#0b6;cursor:pointer;color:#fff;text-decoration:none}
    .btn.warn{background:#f59}
    .small{font-size:13px;color:#665}
    input,select{padding:8px;border:1px solid #ddd;border-radius:6px}
    label{display:block;margin-bottom:6px;font-weight:600}
  </style>
</head>
<body>
  <div class="wrap">
    <header style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
      <div>
        <h1>CRUD — Usuários</h1>
        <div class="small">Logado como: <strong><?= h($user['name'] ?? ''); ?></strong> — <a href="../index.php">Voltar ao site</a></div>
      </div>
    </header>

    <?php if (!empty($msg)): ?>
      <div class="card" style="border-left:4px solid #6c6"><?= h($msg) ?></div>
    <?php endif; ?>

    <?php if (!empty($err)): ?>
      <div class="card" style="border-left:4px solid #c66;color:#900"><strong>Erro:</strong> <?= h($err) ?></div>
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 420px;gap:16px">
      <div class="card">
        <h3 style="margin-top:0">Lista de usuários (últimos 500)</h3>
        <table>
          <thead>
            <tr><th>#</th><th>Nome</th><th>Email</th><th>Admin</th><th>Criado</th><th>Ações</th></tr>
          </thead>
          <tbody>
            <?php foreach ($users as $u): ?>
              <tr>
                <td><?= h($u['id']) ?></td>
                <td><?= h($u['name']) ?></td>
                <td><?= h($u['email']) ?></td>
                <td><?= ($u['is_admin'] == 1) ? 'Sim' : 'Não' ?></td>
                <td><?= h($u['created_at']) ?></td>
                <td>
                  <a class="btn" href="crud.php?edit_id=<?= h($u['id']) ?>">Editar</a>
                  <form class="inline" method="post" action="crud.php" onsubmit="return confirm('Confirmar exclusão do usuário ID <?= h($u['id']) ?>?')">
                    <input type="hidden" name="csrf_token" value="<?= h($CSRF) ?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= h($u['id']) ?>">
                    <button class="btn warn" type="submit">Apagar</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if (count($users) === 0): ?>
              <tr><td colspan="6">Nenhum usuário encontrado.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="card">
        <?php if ($editing): ?>
          <h3>Editar usuário #<?= h($editing['id']) ?></h3>
          <form method="post" action="crud.php">
            <input type="hidden" name="csrf_token" value="<?= h($CSRF) ?>">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" value="<?= h($editing['id']) ?>">

            <label>Nome</label>
            <input name="name" value="<?= h($editing['name']) ?>" required>

            <label>Email</label>
            <input name="email" value="<?= h($editing['email']) ?>" required>

            <label>Senha (deixe em branco para não alterar)</label>
            <input name="password" type="password" placeholder="********">

            <label><input type="checkbox" name="is_admin" value="1" <?= ($editing['is_admin'] == 1) ? 'checked' : '' ?>> Administrador</label>

            <div style="margin-top:12px">
              <button class="btn" type="submit">Salvar</button>
              <a class="btn secondary" href="crud.php" style="margin-left:8px">Cancelar</a>
            </div>
          </form>
        <?php else: ?>
          <h3>Criar novo usuário</h3>
          <form method="post" action="crud.php">
            <input type="hidden" name="csrf_token" value="<?= h($CSRF) ?>">
            <input type="hidden" name="action" value="create">

            <label>Nome</label>
            <input name="name" required>

            <label>Email</label>
            <input name="email" type="email" required>

            <label>Senha</label>
            <input name="password" type="password" required>

            <label><input type="checkbox" name="is_admin" value="1"> Administrador</label>

            <div style="margin-top:12px">
              <button class="btn" type="submit">Criar</button>
            </div>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <footer style="margin-top:18px;color:#665" class="small">Use com responsabilidade — proteja este arquivo em produção.</footer>
  </div>
</body>
</html>
