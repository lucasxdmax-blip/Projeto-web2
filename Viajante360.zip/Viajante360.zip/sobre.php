<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Sobres - Viajante 360</title>
    <link rel="shortcut icon" href="image/logo.png" type="image/x-icon">
    <link href="css/sobres.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@300;400;600&display=swap"
        rel="stylesheet">

    <script>
      window.VI360_USER = <?= json_encode($user, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
      window.API_BASE = "<?= htmlspecialchars($apiBase, ENT_QUOTES) ?>";
    </script>
</head>
<body>
  <header class="site-header">
    <div class="brand">
      <img src="image/logo.png" alt="Viajante 360" class="logo" id="brand-logo">
      <div>
        <h1>Viajante 360</h1>
        <p>Viagens com atitude</p>
      </div>
    <nav id="main-nav" class="main-nav" aria-label="Navegação principal">
      <a href="index.php">Início</a>
      <a href="destinos.php">Destinos</a>
      <a href="reserva.php">Reservas</a>
      <a href="sobre.php" class="active">Sobre</a>
      <a class="cta" href="#reservar">User</a>
    </nav>
   </div>
  </header>

    <div id="auth-modal" class="auth-modal" aria-hidden="true" role="dialog" aria-modal="true">
    <div class="auth-panel">
      <div class="auth-header">
        <img src="image/logo.png" alt="Viajante 360" class="auth-logo">
        <div>
          <h2>Bem-vindo ao Viajante 360</h2>
          <p>Crie sua conta ou entre para desbloquear o acesso.</p>
        </div>
      </div>
      <div class="auth-tabs">
        <button type="button" class="tab-btn active" data-tab="login">Entrar</button>
        <button type="button" class="tab-btn" data-tab="register">Registrar</button>
      </div>
      <div class="auth-body">
        <form id="form-login" class="auth-form active" autocomplete="off">
          <label>Email</label>
          <input type="email" id="login-email" required placeholder="seu@exemplo.com">
          <label>Senha</label>
          <input type="password" id="login-pass" required placeholder="********">
          <button type="submit" class="btn-auth">Entrar</button>
        </form>
        <form id="form-register" class="auth-form" autocomplete="off">
          <label>Nome</label>
          <input type="text" id="reg-name" required placeholder="Seu nome">
          <label>Email</label>
          <input type="email" id="reg-email" required placeholder="seu@exemplo.com">
          <label>Senha</label>
          <input type="password" id="reg-pass" required placeholder="********">
          <button type="submit" class="btn-auth">Registrar</button>
        </form>
      </div>
      <div class="auth-footer">
        <small>É obrigatório — você só poderá navegar após registrar-se ou entrar.</small>
      </div>
    </div>
  </div>
   <!-- Seção principal "Sobre nós" -->
  <main class="sobre-section">
  <div class="container">
    <h2>O Inicio Do Viajante 360</h2>

    <p>
      A Viajante 360 nasceu da paixão genuína por viagens e aviação de um pequeno grupo de fundadores — profissionais de tecnologia, especialistas em turismo e pilotos amadores — que enxergaram uma oportunidade clara: muitas pessoas desejavam experiências aéreas e turísticas únicas, mas se deparavam com processos fragmentados, complicados e demorados para reservas de última hora. A visão inicial foi simples, porém ambiciosa: criar uma plataforma integrada que conectasse operadores locais, voos panorâmicos e serviços de apoio, como transfers e guias turísticos, oferecendo uma experiência completa, confiável e acessível, de forma ágil e intuitiva.
    </p>

    <p>
      No início, a operação era regional, com foco em experiências próximas e facilmente acessíveis. Pilotos parceiros disponibilizavam voos panorâmicos; agências locais ofereciam city tours e passeios guiados; empresas de transfer realizavam trajetos curtos, conectando os usuários com comodidade. A equipe lançou um MVP (Produto Mínimo Viável) com funções básicas de busca e reserva, permitindo validar a demanda por experiências “last-minute”. Esse período inicial trouxe aprendizados valiosos: a importância de sincronizar inventário em tempo real, garantir políticas de cancelamento claras e investir em comunicação transparente com clientes e parceiros.
    </p>

    <p>
      Com o tempo, a Viajante 360 evoluiu para oferecer uma experiência ainda mais completa e confiável. Foram implementados sistemas de pagamento seguros e modernos, painéis de controle robustos para parceiros e funcionalidades adicionais, como mapas interativos, filtros de pesquisa avançados e avaliações detalhadas de experiências. A marca manteve pilares fundamentais: segurança, facilidade de uso e curadoria de experiências — cada parceiro é rigorosamente verificado antes de ter suas atividades listadas. Além disso, a empresa investiu em atendimento dedicado e moderação contínua, garantindo que a qualidade das experiências fosse preservada.
    </p>

    <p>
      Hoje, a Viajante 360 é pensada como uma ponte entre viajantes e fornecedores locais, tornando simples e rápido vivenciar experiências ligadas à aviação e turismo. Sua identidade visual — a paleta de cores verde, preto, branco e cinza, junto à logomarca moderna — reflete os valores da empresa: confiança, modernidade e conexão com a natureza e a aventura. A missão permanece clara: transformar momentos únicos em reservas imediatas, sustentáveis e inesquecíveis, fortalecendo parcerias confiáveis e mantendo o compromisso com um crescimento responsável.
    </p>

    <p>
      A Viajante 360 não é apenas uma plataforma de reservas; é uma experiência de descoberta, feita para quem deseja viver o mundo de forma prática, emocionante e segura.
    </p>
  </div>
</main>

   <footer>
        <div>© <strong>Mígrasoft</strong> · 2025</div>
        <div class="social">
            <a href="#" title="Instagram">IG</a>
            <a href="#" title="Twitter">TW</a>
            <a href="#" title="Contato">📱</a>
        </div>
    </footer>
    <script>
    window.FORCE_AUTH_MODAL = <?= (isset($_GET['logged_out']) && $_GET['logged_out'] == '1') ? 'true' : 'false' ?>;
    </script>
    <script src="js/sobres.js" defer></script>
</body>
</html>