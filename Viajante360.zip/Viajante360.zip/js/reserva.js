(function () {
  const authApiBase = window.API_BASE || '/auth';
  const destinosApiBase = 'destinos_api';
  const reservasApiBase = 'reservas_api';
  let clientUser = null;

  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  }

  function showModal() {
    const modal = document.getElementById('auth-modal');
    if (modal) {
      modal.style.display = 'grid';
      document.body.classList.add('modal-open');
    }
  }

  function hideModal() {
    const modal = document.getElementById('auth-modal');
    if (modal) {
      modal.style.display = 'none';
      document.body.classList.remove('modal-open');
    }
  }

  function updateNavWithUser(user) {
    const nav = document.getElementById('main-nav');
    if (!nav) return;
    nav.innerHTML = `
      <a href="index.php">Início</a>
      <a href="destinos.php">Destinos</a>
      <a href="reserva.php" class="active">Reservas</a>
      <a href="sobre.php">Sobre</a>
      <span style="color:var(--muted);padding:8px 12px;border-radius:10px">Olá, ${escapeHtml(user.name)}</span>
      <button id="btn-logout" class="cta-user" style="border:none;cursor:pointer;margin-left:8px">Sair</button>
    `;
    document.getElementById('btn-logout')?.addEventListener('click', logout);
  }

  async function logout() {
    try {
      await fetch(`${authApiBase}/logout.php`, { method: 'POST' });
    } finally {
      localStorage.removeItem('vi360_user');
      location.reload();
    }
  }

  function closeModalAndUpdate(user) {
    try {
      localStorage.setItem('vi360_user', JSON.stringify(user));
      clientUser = user;
    } catch (e) {}
    hideModal();
    updateNavWithUser(user);
    loadPageData();
  }

  async function postJson(url, payload) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    return res.json();
  }
  
  function setupAuthHandlers() {
    document.getElementById('form-login')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email')?.value.trim();
      const pass = document.getElementById('login-pass')?.value.trim();
      if (!email || !pass) return alert('Preencha email e senha.');
      try {
        const data = await postJson(`${authApiBase}/login.php`, { email, password: pass });
        if (data.success) closeModalAndUpdate(data.user);
        else alert(data.message || 'Erro ao logar.');
      } catch (err) {
        alert('Erro de conexão ao tentar fazer login.');
      }
    });

    document.getElementById('form-register')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('reg-name')?.value.trim();
      const email = document.getElementById('reg-email')?.value.trim();
      const pass = document.getElementById('reg-pass')?.value.trim();
      if (!name || !email || !pass) return alert('Preencha todos os campos.');
      try {
        const data = await postJson(`${authApiBase}/register.php`, { name, email, password: pass });
        if (data.success) closeModalAndUpdate(data.user);
        else alert(data.message || 'Erro ao registrar.');
      } catch (err) {
        alert('Erro de conexão ao tentar registrar.');
      }
    });

    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const tab = btn.getAttribute('data-tab');
        document.querySelectorAll('.auth-form').forEach(f => f.classList.toggle('active', f.id === `form-${tab}`));
      });
    });
  }


  async function loadDestinos() {
    const select = document.getElementById('destino-select');
    try {
      const res = await fetch(`${destinosApiBase}/list_destino.php`);
      const json = await res.json();
      if (json.success && json.data.length > 0) {
        select.innerHTML = '<option value="">Selecione um destino</option>';
        json.data.forEach(d => {
          if(d.disponivel == 1) {
            const option = document.createElement('option');
            option.value = d.id;
            option.textContent = `${d.titulo} - ${d.localizacao}`;
            select.appendChild(option);
          }
        });
      } else {
        select.innerHTML = '<option value="">Nenhum destino disponível</option>';
      }
    } catch (error) {
      select.innerHTML = '<option value="">Erro ao carregar destinos</option>';
    }
  }

  function renderReservas(reservas = []) {
    const lista = document.getElementById('lista-reservas');
    if (reservas.length === 0) {
      lista.innerHTML = '<p>Nenhuma viagem agendada ainda.</p>';
      return;
    }
    lista.innerHTML = reservas.map(r => `
      <div class="reserva-card" data-id="${r.id}">
        <img src="image/${r.destino_imagem || 'placeholder.jpg'}" alt="" class="thumb">
        <div class="info">
          <h4>${escapeHtml(r.destino_titulo)}</h4>
          <p>Data: ${new Date(r.data_reserva).toLocaleDateString('pt-BR', {timeZone: 'UTC'})} | Status: ${escapeHtml(r.status)}</p>
        </div>
        <button class="btn-cancel" data-id="${r.id}">Cancelar</button>
      </div>
    `).join('');

    document.querySelectorAll('.btn-cancel').forEach(btn => {
        btn.addEventListener('click', handleCancelReserva);
    });
  }


  async function loadReservas() {
    const lista = document.getElementById('lista-reservas');
    lista.innerHTML = '<p>Carregando suas reservas...</p>';
    try {
      const res = await fetch(`${reservasApiBase}/list_reservas.php`);
      const json = await res.json();
      if (json.success) {
        renderReservas(json.data);
      } else {
        lista.innerHTML = `<p>${json.error || 'Erro ao carregar reservas.'}</p>`;
      }
    } catch (error) {
      lista.innerHTML = '<p>Erro de conexão ao buscar reservas.</p>';
    }
  }

  async function handleCreateReserva(e) {
    e.preventDefault();
    const form = e.target;
    const destino_id = form.querySelector('#destino-select').value;
    const data_reserva = form.querySelector('#data-reserva').value;
    const msgArea = document.getElementById('reserva-msg');

    if (!destino_id || !data_reserva) {
      msgArea.textContent = 'Por favor, selecione um destino e uma data.';
      return;
    }
    
    try {
      const data = await postJson(`${reservasApiBase}/create_reserva.php`, { destino_id, data_reserva });
      if (data.success) {
        msgArea.textContent = data.message;
        form.reset();
        loadReservas();
        setTimeout(() => msgArea.textContent = '', 3000);
      } else {
        msgArea.textContent = data.error || 'Não foi possível fazer a reserva.';
      }
    } catch (error) {
      msgArea.textContent = 'Erro de conexão ao criar reserva.';
    }
  }

  async function handleCancelReserva(e) {
    const id = e.target.dataset.id;
    if (!confirm('Tem certeza que deseja cancelar esta reserva?')) return;
    
    try {
        const data = await postJson(`${reservasApiBase}/delete_reserva.php`, { id });
        if(data.success) {
            loadReservas();
        } else {
            alert(data.error || 'Não foi possível cancelar a reserva.');
        }
    } catch (error) {
        alert('Erro de conexão ao cancelar a reserva.');
    }
  }
  
  function loadPageData() {
      if(clientUser) {
        loadDestinos();
        loadReservas();
      }
  }

  document.addEventListener('DOMContentLoaded', () => {
    clientUser = (window.VI360_USER && window.VI360_USER.name) ? window.VI360_USER : JSON.parse(localStorage.getItem('vi360_user') || 'null');
    
    setupAuthHandlers();

    if (!clientUser) {
      showModal();
    } else {
      hideModal();
      updateNavWithUser(clientUser);
      loadPageData();
    }
    
    document.getElementById('form-reserva')?.addEventListener('submit', handleCreateReserva);
  });
})();

// -- Feito por Gustavo. ---