<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'Método não permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$email = trim($input['email'] ?? '');
$pass  = $input['password'] ?? '';

if ($email === '' || $pass === '') {
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Preencha email e senha.']);
    exit;
}

try {
    $stmt = $pdo->prepare('SELECT id, name, email, password_hash FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($pass, $user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['success'=>false,'message'=>'Credenciais inválidas.']);
        exit;
    }

    unset($user['password_hash']);
    $stmt = $pdo->prepare('SELECT id, name, email, is_admin FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$user['id']]);
    $userRow = $stmt->fetch();

    $_SESSION['user'] = [
    'id' => (int)$userRow['id'],
    'name' => $userRow['name'],
    'email' => $userRow['email'],
    'is_admin' => !empty($userRow['is_admin']) ? 1 : 0
    ];
echo json_encode(['success'=>true,'message'=>'Logado com sucesso','user'=>$_SESSION['user']]);
} catch (Exception $e) {
    http_response_code(500);
    @file_put_contents(__DIR__ . '/debug.log', '['.date('c')."] login error: ".$e->getMessage()."\n", FILE_APPEND);
    echo json_encode(['success'=>false,'message'=>'Erro interno no servidor.']);
    exit;
}
