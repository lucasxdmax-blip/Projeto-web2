(function () {
  const API_BASE = (window.API_BASE && String(window.API_BASE)) || (function () {
    const path = location.pathname.replace(/\/+$/, '');
    const parts = path.split('/');
    parts.pop();
    const base = parts.join('/') || '';
    return base + '/auth';
  })();

  document.addEventListener('click', function(e) {
    const a = e.target.closest('a');
    if (!a) return;
    const href = a.getAttribute('href') || '';
    if (href.startsWith('#') && href.length > 1) {
      e.preventDefault();
      const target = document.querySelector(href);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }
    if (href === '#') {
      e.preventDefault();
      return;
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('auth-modal');
    const formLogin = document.getElementById('form-login');
    const formRegister = document.getElementById('form-register');
    const tabBtns = Array.from(document.querySelectorAll('.tab-btn'));
    const nav = document.getElementById('main-nav');
    let scrollPosition = 0;

    function lockScroll() {
      scrollPosition = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
      document.body.style.top = `-${scrollPosition}px`;
      document.body.style.position = 'fixed';
      document.body.style.width = '100%';
      document.body.classList.add('modal-open');
    }

    function unlockScroll() {
      document.body.classList.remove('modal-open');
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, scrollPosition);
    }

    function showModal() {
      if (!modal) return;
      modal.style.display = 'grid';
      lockScroll();
      const activeInput = modal.querySelector('.auth-form.active input');
      if (activeInput) activeInput.focus();
    }


    function hideModal() {
      if (!modal) return;
      modal.style.display = 'none';
      unlockScroll();
    }

    if (window.FORCE_AUTH_MODAL) {
      showModal();
    }

    if (modal) {
      modal.addEventListener('click', e => e.stopPropagation());
      const panel = modal.querySelector('.auth-panel');
      if (panel) panel.addEventListener('click', e => e.stopPropagation());
      window.addEventListener('keydown', e => {
        if (e.key === 'Escape') e.preventDefault();
      });
    }

    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const t = btn.getAttribute('data-tab');
        document.querySelectorAll('.auth-form').forEach(f => f.classList.toggle('active', f.id === `form-${t}`));
        const ai = document.querySelector(`#form-${t} input`);
        if (ai) ai.focus();
      });
    });

    function escapeHtml(str) {
      return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
    }

    function updateNavWithUser(user) {
      if (!nav) return;
      nav.innerHTML = `
        <a href="index.php">Início</a>
        <a href="destinos.php" class="active">Destinos</a>
        <a href="reserva.php">Reservas</a>
        <a href="sobre.php">Sobre</a>
        <span style="color:var(--muted);padding:8px 12px;border-radius:10px">Olá, ${escapeHtml(user.name)}</span>
        <button id="btn-logout" class="cta" style="border:none;cursor:pointer;margin-left:8px">Sair</button>
      `;
      const btnLogout = document.getElementById('btn-logout');
      if (btnLogout) {
        btnLogout.addEventListener('click', async () => {
          try {
            await fetch(API_BASE + '/logout.php', { method: 'POST' });
          } catch (err) {}
          try { localStorage.removeItem('vi360_user'); } catch (e) {}
          location.reload();
        });
      }
    }

    function closeModalAndUpdate(user) {
      try { localStorage.setItem('vi360_user', JSON.stringify(user)); } catch (e) {}
      hideModal();
      updateNavWithUser(user);
    }

    const clientUser = (window.VI360_USER && window.VI360_USER.name) ? window.VI360_USER : (function () {
      try {
        return JSON.parse(localStorage.getItem('vi360_user') || 'null');
      } catch (e) { return null; }
    })();

    if (!clientUser) {
      showModal();
    } else {
      hideModal();
      updateNavWithUser(clientUser);
    }

    async function postJson(url, payload) {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const text = await res.text();
      try {
        return JSON.parse(text);
      } catch (e) {
        throw new Error('Resposta inesperada do servidor: ' + text);
      }
    }

    if (formLogin) {
      formLogin.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = (document.getElementById('login-email')?.value || '').trim();
        const pass = (document.getElementById('login-pass')?.value || '').trim();
        if (!email || !pass) { alert('Preencha email e senha.'); return; }
        try {
          const data = await postJson(API_BASE + '/login.php', { email, password: pass });
          if (data && data.success) {
            const user = data.user || { name: email.split('@')[0], email };
            closeModalAndUpdate(user);
          } else {
            alert(data.message || 'Erro ao logar.');
          }
        } catch (err) {
          alert('Erro de conexão com o servidor.');
        }
      });
    }

    if (formRegister) {
      formRegister.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = (document.getElementById('reg-name')?.value || '').trim();
        const email = (document.getElementById('reg-email')?.value || '').trim();
        const pass = (document.getElementById('reg-pass')?.value || '').trim();
        if (!name || !email || !pass) { alert('Preencha todos os campos para registrar.'); return; }
        try {
          const data = await postJson(API_BASE + '/register.php', { name, email, password: pass });
          if (data && data.success) {
            const user = data.user || { name, email };
            closeModalAndUpdate(user);
          } else {
            alert(data.message || 'Erro ao registrar.');
          }
        } catch (err) {
          alert('Erro de conexão com o servidor.');
        }
      });
    }
  });
})();

(function () {
  const box = document.getElementById('descricaoBox');
  const btn = document.getElementById('toggle-desc');
  if (!box || !btn) return;

  const COLLAPSED_HEIGHT = 50;
  const ANIMATION_MS = 240;

  requestAnimationFrame(() => {
    const contentHeight = box.scrollHeight;
    if (contentHeight > COLLAPSED_HEIGHT + 8) {
      box.style.maxHeight = COLLAPSED_HEIGHT + 'px';
      box.style.overflow = 'auto';
      box.style.transition = `max-height ${ANIMATION_MS}ms ease`;
      btn.style.display = '';
    } else {
      box.style.maxHeight = 'none';
      box.style.overflow = 'visible';
      btn.style.display = 'none';
    }
  });

  btn.addEventListener('click', () => {
    const expanded = btn.getAttribute('data-expanded') === 'true';
    if (!expanded) {
      const target = box.scrollHeight + 24;
      box.style.maxHeight = target + 'px';
      btn.textContent = 'Mostrar menos';
      btn.setAttribute('data-expanded', 'true');
      btn.setAttribute('aria-expanded', 'true');
      setTimeout(() => {
        box.style.maxHeight = 'none';
        box.style.overflow = 'auto';
      }, ANIMATION_MS + 20);
      box.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const cur = box.scrollHeight;
      box.style.maxHeight = (cur) + 'px';
      requestAnimationFrame(() => {
        box.style.maxHeight = COLLAPSED_HEIGHT + 'px';
      });
      btn.textContent = 'Mostrar mais';
      btn.setAttribute('data-expanded', 'false');
      btn.setAttribute('aria-expanded', 'false');
      setTimeout(() => {
        btn.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, ANIMATION_MS);
    }
  });

  try {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mq && mq.matches) {
      box.style.transition = 'none';
    }
  } catch(e){}
})();

(function () {
  'use strict';

  function q(sel, root=document) { return root.querySelector(sel); }
  function qa(sel, root=document) { return Array.from(root.querySelectorAll(sel)); }

  function initDescToggle() {
    const box = q('#descricaoBox');
    const btn = q('#toggle-desc');
    if (!box || !btn) return;

    const COLLAPSED = 120;
    const contentHeight = box.scrollHeight;
    if (contentHeight > COLLAPSED + 8) {
      box.style.maxHeight = COLLAPSED + 'px';
      box.style.overflow = 'auto';
      btn.style.display = '';
      btn.dataset.expanded = 'false';
      btn.setAttribute('aria-expanded', 'false');
      btn.textContent = 'Mostrar mais';
      btn.addEventListener('click', () => {
        const exp = btn.dataset.expanded === 'true';
        if (!exp) {
          box.style.maxHeight = box.scrollHeight + 24 + 'px';
          btn.dataset.expanded = 'true';
          btn.setAttribute('aria-expanded', 'true');
          btn.textContent = 'Mostrar menos';
          setTimeout(() => { box.style.maxHeight = 'none'; }, 260);
        } else {
          const cur = box.scrollHeight;
          box.style.maxHeight = cur + 'px';
          requestAnimationFrame(() => {
            box.style.maxHeight = COLLAPSED + 'px';
          });
          btn.dataset.expanded = 'false';
          btn.setAttribute('aria-expanded', 'false');
          btn.textContent = 'Mostrar mais';
        }
      });
    } else {
      btn.style.display = 'none';
      box.style.maxHeight = 'none';
    }
  }

  function initStarInput() {
    const stars = qa('#star-input .star');
    const input = q('#rating-input');
    if (!stars.length || !input) return;

    let selected = Number(input.value) || 0;

    function highlight(v) {
      stars.forEach(s => {
        const val = Number(s.dataset.value || s.getAttribute('data-value') || 0);
        if (val <= v) s.classList.add('filled'); else s.classList.remove('filled');
      });
    }

    stars.forEach(s => {
      s.addEventListener('mouseenter', () => {
        highlight(Number(s.dataset.value));
      });
      s.addEventListener('mouseleave', () => {
        highlight(selected);
      });
      s.addEventListener('click', () => {
        selected = Number(s.dataset.value);
        input.value = String(selected);
        highlight(selected);
      });
    });

    highlight(selected);
  }

  function bindClearReview() {
    const btn = q('#btn-clear-review');
    const comment = q('#review-comment');
    const input = q('#rating-input');
    if (!btn) return;
    btn.addEventListener('click', () => {
      if (comment) comment.value = '';
      if (input) input.value = '0';
      qa('#star-input .star').forEach(s => s.classList.remove('filled'));
    });
  }

  function forceAuthIfNeeded() {
    const user = window.VI360_USER || (function(){ try { return JSON.parse(localStorage.getItem('vi360_user')||'null'); } catch(e){ return null; } })();
    const force = window.FORCE_AUTH_MODAL === true || window.FORCE_AUTH_MODAL === 'true';
    if (!user || force) {
      if (typeof showAuthModal === 'function') {
        showAuthModal();
      } else {
        const modal = document.getElementById('auth-modal');
        if (modal) {
          modal.style.display = 'grid';
          document.body.classList.add('modal-open');
        }
      }
    }
  }

  function lockModalBehaviour() {
    const modal = document.getElementById('auth-modal');
    if (!modal) return;
    modal.addEventListener('click', (e) => e.stopPropagation());
    const panel = modal.querySelector('.auth-panel');
    if (panel) panel.addEventListener('click', (e) => e.stopPropagation());
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
      }
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    initDescToggle();
    initStarInput();
    bindClearReview();
    lockModalBehaviour();
    forceAuthIfNeeded();
  });
})();

(function(){
  const btnReserve = document.getElementById('btn-reserve');
  const paymentModal = document.getElementById('payment-modal');
  const pmCancel = document.getElementById('pm-cancel');
  const pmPay = document.getElementById('pm-pay');
  const pmMsg = document.getElementById('pm-msg');
  const reserveForm = document.getElementById('reserve-form');

  function showPayment() {
    if (!paymentModal) return;
    paymentModal.style.display = 'flex';
    pmMsg.textContent = '';
    document.body.classList.add('modal-open1');
    document.body.style.filter = '';
    document.body.style.pointerEvents = '';
  }
  function hidePayment() {
    if (!paymentModal) return;
    paymentModal.style.display = 'none';
    document.body.classList.remove('modal-open1');
    document.body.style.filter = '';
    document.body.style.pointerEvents = '';
  }

  if (btnReserve) {
    btnReserve.addEventListener('click', () => {
      const guests = Number(document.getElementById('guests')?.value || 1);
      if (guests < 1) { alert('Quantidade inválida'); return; }
      const clientUser = window.VI360_USER || (function(){ try { return JSON.parse(localStorage.getItem('vi360_user') || 'null'); } catch(e){ return null; }})();
      if (!clientUser) {
        const modal = document.getElementById('auth-modal');
        if (modal) { modal.style.display = 'grid'; document.body.classList.add('modal-open1'); }
        return;
      }
      showPayment();
    });
  }

  if (pmCancel) {
    pmCancel.addEventListener('click', () => {
      hidePayment();
    });
  }

  if (pmPay) {
    pmPay.addEventListener('click', async () => {
      pmPay.disabled = true;
      pmPay.textContent = 'Processando...';
      pmMsg.textContent = 'Simulando transação...';
      await new Promise(r => setTimeout(r, 1200));

      const fd = new FormData(reserveForm);
      const payload = {
        csrf_token: fd.get('csrf_token'),
        destino_id: fd.get('destino_id'),
        guests: Number(fd.get('guests') || 1)
      };

      try {
        const res = await fetch(window.API_BASE + '../reservas_api/create_reserva.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const json = await res.json();
        if (!json.success) {
          pmMsg.textContent = json.error || 'Erro ao processar reserva.';
          pmPay.disabled = false;
          pmPay.textContent = 'Pagar (simular)';
          return;
        }
        pmMsg.textContent = 'Pagamento e reserva realizados com sucesso!';
        setTimeout(() => {
          const rid = json.reservation_id ? ('?id=' + encodeURIComponent(json.reservation_id)) : '';
          window.location.href = 'reserva.php' + rid;
        }, 700);
      } catch (err) {
        pmMsg.textContent = 'Erro de conexão ao criar reserva.';
        pmPay.disabled = false;
        pmPay.textContent = 'Pagar (simular)';
      }
    });
  }

  const starInput = document.getElementById('star-input');
  const ratingInput = document.getElementById('rating-input');
  if (starInput && ratingInput) {
    starInput.addEventListener('click', (ev) => {
      const s = ev.target.closest('.star');
      if (!s) return;
      const val = Number(s.getAttribute('data-value') || 0);
      ratingInput.value = val;
      Array.from(starInput.querySelectorAll('.star')).forEach(sp => {
        sp.classList.toggle('filled', Number(sp.getAttribute('data-value')) <= val);
      });
    });
  }

  const reviewForm = document.getElementById('review-form');
  if (reviewForm) {
    reviewForm.addEventListener('submit', (e) => {
      const clientUser = window.VI360_USER || (function(){ try { return JSON.parse(localStorage.getItem('vi360_user') || 'null'); } catch(e){ return null; }})();
      if (!clientUser) {
        e.preventDefault();
        const modal = document.getElementById('auth-modal');
        if (modal) { modal.style.display = 'grid'; document.body.classList.add('modal-open'); }
        return;
      }
    });
  }

  const btnClear = document.getElementById('btn-clear-review');
  if (btnClear) {
    btnClear.addEventListener('click', () => {
      document.getElementById('rating-input').value = '0';
      document.getElementById('review-comment').value = '';
      const stars = document.querySelectorAll('#star-input .star');
      stars.forEach(s => s.classList.remove('filled'));
    });
  }

  const toggleDesc = document.getElementById('toggle-desc');
  if (toggleDesc) {
    const box = document.getElementById('descricaoBox');
    if (box) {
      box.style.transition = 'max-height 240ms ease';
      const contentHeight = box.scrollHeight;
      if (contentHeight > 160) {
        box.style.maxHeight = '60px';
        box.style.overflow = 'hidden';
        toggleDesc.style.display = '';
      } else {
        toggleDesc.style.display = 'none';
      }
    }
    toggleDesc.addEventListener('click', () => {
      const box = document.getElementById('descricaoBox');
      if (!box) return;
      const expanded = toggleDesc.getAttribute('data-expanded') === 'true';
      if (!expanded) {
        const target = box.scrollHeight + 24;
        box.style.maxHeight = target + 'px';
        toggleDesc.textContent = 'Mostrar menos';
        toggleDesc.setAttribute('data-expanded', 'true');
        toggleDesc.setAttribute('aria-expanded', 'true');
        setTimeout(() => { box.style.maxHeight = 'none'; box.style.overflow = 'auto'; }, 260);
      } else {
        box.style.maxHeight = '60px';
        box.style.overflow = 'hidden';
        toggleDesc.textContent = 'Mostrar mais';
        toggleDesc.setAttribute('data-expanded', 'false');
        toggleDesc.setAttribute('aria-expanded', 'false');
      }
    });
  }
})();