<?php
// create_reserva.php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) session_start();

// carrega config / PDO
require_once __DIR__ . '/../config.php';
if (!isset($pdo) && function_exists('pdo')) {
    $pdo = pdo();
}
if (!isset($pdo)) {
    if (defined('DB_HOST') && defined('DB_NAME')) {
        $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".(defined('DB_CHARSET')?DB_CHARSET:'utf8mb4');
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success'=>false, 'message'=>'Configuração do DB não encontrada.']);
        exit;
    }
}

// recebido via POST (form ou fetch)
$input = $_POST ?: json_decode(file_get_contents('php://input'), true) ?: [];
$destinoId = isset($input['destino_id']) ? (int)$input['destino_id'] : 0;
$guests = isset($input['guests']) ? max(1,(int)$input['guests']) : 1;
$data_reserva = $input['data_reserva'] ?? date('Y-m-d');

// usuário autenticado (se não, aceita user_id opcional para testes)
$user = $_SESSION['user'] ?? null;
$user_id = $user['id'] ?? (isset($input['user_id']) ? (int)$input['user_id'] : 0);
if ($user_id <= 0) {
    http_response_code(401);
    echo json_encode(['success'=>false, 'message'=>'Usuário não autenticado.']);
    exit;
}

if ($destinoId <= 0) {
    http_response_code(400);
    echo json_encode(['success'=>false, 'message'=>'destino_id inválido.']);
    exit;
}

try {
    // pega preço atual do destino (snapshot)
    $q = $pdo->prepare("SELECT id, titulo, preco FROM destinos WHERE id = :id LIMIT 1");
    $q->execute([':id' => $destinoId]);
    $dest = $q->fetch();
    if (!$dest) {
        http_response_code(404);
        echo json_encode(['success'=>false, 'message'=>'Destino não encontrado.']);
        exit;
    }

    $price = (float)$dest['preco'];
    $total = round($price * $guests, 2);

    // cria token de pagamento (único)
    $payment_token = bin2hex(random_bytes(16));
    $payment_ref = null;

    // insere reserva com status pending_payment
    $stmt = $pdo->prepare("INSERT INTO reservas (user_id, destino_id, price_snapshot, currency, total_amount, data_reserva, status, guests, created_at) VALUES (:user_id, :destino_id, :price_snapshot, :currency, :total_amount, :data_reserva, :status, :guests, NOW())");
    $stmt->execute([
        ':user_id' => $user_id,
        ':destino_id' => $destinoId,
        ':price_snapshot' => number_format($price,2,'.',''),
        ':currency' => 'BRL',
        ':total_amount' => number_format($total,2,'.',''),
        ':data_reserva' => $data_reserva,
        ':status' => 'pending_payment',
        ':guests' => $guests
    ]);
    $reserva_id = (int)$pdo->lastInsertId();

    // armazena token/associação em tabela de pagamentos simples (se não existir, usa coluna extra na reservas)
    // Aqui vamos gravar na própria tabela reservas usando uma coluna 'payment_token' se existir, caso contrário criaremos um registro simples em arquivo.
    $hasPaymentTokenCol = false;
    $cols = $pdo->query("SHOW COLUMNS FROM reservas LIKE 'payment_token'")->fetch();
    if ($cols) {
        $hasPaymentTokenCol = true;
        $u = $pdo->prepare("UPDATE reservas SET payment_token = :t WHERE id = :id");
        $u->execute([':t' => $payment_token, ':id' => $reserva_id]);
    } else {
        // fallback: grava token em arquivo temporário (somente dev)
        $tmp = sys_get_temp_dir() . "/viajante_payment_tokens.json";
        $store = [];
        if (file_exists($tmp)) {
            $store = json_decode(file_get_contents($tmp), true) ?: [];
        }
        $store[$payment_token] = ['reserva_id' => $reserva_id, 'total' => $total, 'created_at' => time()];
        file_put_contents($tmp, json_encode($store));
    }

    // Payment URL local (simulação)
    $base = rtrim(dirname((isset($_SERVER['SCRIPT_NAME'])?$_SERVER['SCRIPT_NAME']:'/')).'/','/');
    $payment_url = $base . "/payment_simulate.php?token=" . $payment_token;

    echo json_encode([
        'success' => true,
        'reserva_id' => $reserva_id,
        'payment_token' => $payment_token,
        'payment_url' => $payment_url,
        'total' => number_format($total,2,'.','')
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Erro no servidor: '.$e->getMessage()]);
}
