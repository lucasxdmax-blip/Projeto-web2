<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/token_csrf.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido.']);
    exit;
}

$token = $_POST['csrf_token'] ?? '';
if (!validate_csrf_token($token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Token CSRF inválido.']);
    exit;
}

if (empty($_SESSION['user']) || !isset($_SESSION['user']['is_admin']) || (int)$_SESSION['user']['is_admin'] !== 1) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Ação permitida apenas para administradores.']);
    exit;
}

$titulo = trim($_POST['titulo'] ?? '');
$descricao = trim($_POST['descricao'] ?? '');
$preco = $_POST['preco'] ?? null;
$localizacao = trim($_POST['localizacao'] ?? '');
$disponivel = isset($_POST['disponivel']) && $_POST['disponivel'] == '1' ? 1 : 0;

$errors = [];

if ($titulo === '') $errors[] = 'Título é obrigatório.';
if ($descricao === '') $errors[] = 'Descrição é obrigatória.';
if ($preco !== null && $preco !== '') {
    if (!is_numeric(str_replace(',', '.', $preco))) $errors[] = 'Preço inválido.';
    else $preco = number_format((float) str_replace(',', '.', $preco), 2, '.', '');
} else {
    $preco = null;
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

$uploadedFileName = null;

if (!empty($_FILES['imagem']['name'])) {
    $file = $_FILES['imagem'];
    $allowed = ['image/jpeg','image/png','image/webp'];
    if (!in_array($file['type'], $allowed)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Tipo de imagem não permitido.']);
        exit;
    }

    if ($file['size'] > 4 * 1024 * 1024) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Imagem muito grande (max 4MB).']);
        exit;
    }

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $name = time() . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
    $dest = __DIR__ . '/../image/' . $name;

    if (!is_dir(__DIR__ . '/../image')) mkdir(__DIR__ . '/../image', 0755, true);

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Falha ao mover imagem.']);
        exit;
    }
    $uploadedFileName = $name;
}

try {
    $sql = "INSERT INTO destinos (titulo, descricao, preco, localizacao, imagem, disponivel, created_at)
            VALUES (:titulo, :descricao, :preco, :localizacao, :imagem, :disponivel, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':titulo' => $titulo,
        ':descricao' => $descricao,
        ':preco' => $preco,
        ':localizacao' => $localizacao !== '' ? $localizacao : null,
        ':imagem' => $uploadedFileName,
        ':disponivel' => $disponivel ? 1 : 0
    ]);

    $id = $pdo->lastInsertId();
    $stmt = $pdo->prepare("SELECT * FROM destinos WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    echo json_encode(['success' => true, 'data' => $row]);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro no servidor.']);
    exit;
}
