const apiBase = 'destinos_api';

function escapeHtml(s) {
  if (!s) return s;
  return s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

async function postJson(url, payload) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const text = await res.text();
  try { return JSON.parse(text); }
  catch (e) { throw new Error('Resposta inesperada do servidor: ' + text); }
}

let clientUser = window.VI360_USER || (function () {
  try { return JSON.parse(localStorage.getItem('vi360_user') || 'null'); }
  catch (e) { return null; }
})();

function showAuthModal() {
  const modal = document.getElementById('auth-modal');
  if (!modal) return;
  modal.style.display = 'grid';
  document.body.classList.add('modal-open');
  const activeInput = modal.querySelector('.auth-form.active input');
  if (activeInput) activeInput.focus();
}

function hideAuthModal() {
  const modal = document.getElementById('auth-modal');
  if (!modal) return;
  modal.style.display = 'none';
  document.body.classList.remove('modal-open');
}

function updateNavWithUser(user) {
  const nav = document.getElementById('main-nav');
  if (!nav) return;
  nav.innerHTML = `
    <a href="index.php">Início</a>
    <a href="destinos.php" class="active">Destinos</a>
    <a href="reserva.php">Reservas</a>
    <a href="sobre.php">Sobre</a>
    <span style="color:var(--muted);padding:8px 12px;border-radius:10px">Olá, ${escapeHtml(user.name)}</span>
    <button id="btn-logout" class="cta" style="border:none;cursor:pointer;margin-left:8px">Sair</button>
  `;
  const btnLogout = document.getElementById('btn-logout');
  if (btnLogout) {
    btnLogout.addEventListener('click', async () => {
      try { await fetch(window.API_BASE + '/logout.php', { method: 'POST' }); } catch(e){}
      try { localStorage.removeItem('vi360_user'); } catch(e){}
      clientUser = null;
      window.VI360_USER = null;
      location.reload();
    });
  }
}

function setBtnNovoVisibility() {
  const btnNovo = document.getElementById('btn-novo');
  if (!btnNovo) return;
  const isAdmin = clientUser && Number(clientUser.is_admin) === 1;
  btnNovo.style.display = isAdmin ? '' : 'none';
}

function onAuthSuccess(user) {
  clientUser = user;
  window.VI360_USER = user;
  try { localStorage.setItem('vi360_user', JSON.stringify(user)); } catch(e){}
  hideAuthModal();
  updateNavWithUser(user);
  setBtnNovoVisibility();
  loadListData();
}

const DESC_COLLAPSED_HEIGHT = 30;
const DESC_ANIM_MS = 220;

function initDescriptionToggles(root = document) {
  const wrappers = root.querySelectorAll('.descricao-wrapper');
  wrappers.forEach(wrapper => {
    const box = wrapper.querySelector('.descricao-box');
    const btn = wrapper.querySelector('.desc-toggle');
    if (!box || !btn) return;
    box.style.transition = `max-height ${DESC_ANIM_MS}ms ease`;
    box.style.overflow = 'hidden';
    btn.style.display = 'none';
    btn.setAttribute('data-expanded', 'false');
    btn.setAttribute('aria-expanded', 'false');
    btn.textContent = 'Mostrar mais';
    const contentHeight = box.scrollHeight;
    if (contentHeight > DESC_COLLAPSED_HEIGHT + 8) {
      box.style.maxHeight = DESC_COLLAPSED_HEIGHT + 'px';
      box.style.overflow = 'auto';
      btn.style.display = '';
    } else {
      box.style.maxHeight = 'none';
      box.style.overflow = 'visible';
      btn.style.display = 'none';
    }
  });
}

document.addEventListener('click', (e) => {
  const btn = e.target.closest('.desc-toggle');
  if (!btn) return;
  const wrapper = btn.closest('.descricao-wrapper');
  if (!wrapper) return;
  const box = wrapper.querySelector('.descricao-box');
  if (!box) return;
  const expanded = btn.getAttribute('data-expanded') === 'true';
  if (!expanded) {
    const target = box.scrollHeight + 24;
    box.style.maxHeight = target + 'px';
    btn.textContent = 'Mostrar menos';
    btn.setAttribute('data-expanded', 'true');
    btn.setAttribute('aria-expanded', 'true');
    setTimeout(() => { box.style.maxHeight = 'none'; box.style.overflow = 'auto'; }, DESC_ANIM_MS + 20);
  } else {
    const cur = box.scrollHeight;
    box.style.maxHeight = cur + 'px';
    requestAnimationFrame(() => {
      box.style.maxHeight = DESC_COLLAPSED_HEIGHT + 'px';
      box.style.overflow = 'auto';
    });
    btn.textContent = 'Mostrar mais';
    btn.setAttribute('data-expanded', 'false');
    btn.setAttribute('aria-expanded', 'false');
    setTimeout(() => { btn.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, DESC_ANIM_MS);
  }
});

let ALL_DESTINOS = [];
const FILTER_STATE = { q: '', country: '', priceMin: null, priceMax: null, perPage: 6, page: 1 };

function applyFiltersAndPaginate() {
  let results = ALL_DESTINOS.slice();
  const q = (FILTER_STATE.q || '').trim().toLowerCase();
  if (q) results = results.filter(d => ((d.titulo||'') + ' ' + (d.descricao||'')).toLowerCase().includes(q));
  if (FILTER_STATE.country) results = results.filter(d => (d.localizacao||'').toLowerCase().includes(FILTER_STATE.country.toLowerCase()));
  if (FILTER_STATE.priceMin !== null) results = results.filter(d => { const p = (d.preco === null || d.preco === '') ? null : Number(d.preco); return p !== null && p >= Number(FILTER_STATE.priceMin); });
  if (FILTER_STATE.priceMax !== null) results = results.filter(d => { const p = (d.preco === null || d.preco === '') ? null : Number(d.preco); return p !== null && p <= Number(FILTER_STATE.priceMax); });
  const perPage = Number(FILTER_STATE.perPage) || 6;
  const total = results.length;
  const totalPages = Math.max(1, Math.ceil(total / perPage));
  let page = Number(FILTER_STATE.page) || 1;
  if (page < 1) page = 1;
  if (page > totalPages) page = totalPages;
  const start = (page - 1) * perPage;
  const items = results.slice(start, start + perPage);
  return { items, total, totalPages, page, perPage };
}

function renderStarsHTML(avg, count) {
  const a = Number(avg) || 0;
  const rounded = Math.round(a);
  let out = '<div class="card-stars" aria-hidden="true">';
  for (let i = 1; i <= 5; i++) out += `<span class="star${i <= rounded ? ' filled' : ''}">★</span>`;
  out += ` <span class="stars-count">${a > 0 ? a.toFixed(1) : '-'}</span>`;
  if (typeof count !== 'undefined') out += ` <span class="stars-muted">(${count})</span>`;
  out += '</div>';
  return out;
}

function renderGrid(items) {
  const lista = document.getElementById('lista-destinos');
  if (!lista) return;
  if (!items || items.length === 0) { lista.innerHTML = '<div class="msg-area">Nenhum destino encontrado.</div>'; return; }
  const isAdmin = clientUser && Number(clientUser.is_admin) === 1;
  const html = items.map(d => {
    const img = d.imagem ? `<div class="thumb"><img src="image/destinos/${escapeHtml(d.imagem)}" alt="${escapeHtml(d.titulo)}" class="cover-img"></div>` : '<div class="thumb" style="display:flex;align-items:center;justify-content:center;height:160px">Sem imagem</div>';
    const disponibilidade = `<span class="badge${d.disponivel == 1 ? ' available' : ''}">${d.disponivel == 1 ? 'Disponível' : 'Indisponível'}</span>`;
    const preco = d.preco !== null && d.preco !== '' ? ('R$ ' + Number(d.preco).toFixed(2)) : 'Preço sob consulta';
    const descricaoHtml = `<div class="descricao-wrapper"><div class="descricao-box" role="region" aria-label="Descrição do destino"><div class="descricao-content">${escapeHtml(d.descricao || '')}</div></div><button type="button" class="desc-toggle btn ghost" aria-expanded="false" style="display:none;margin-top:8px">Mostrar mais</button></div>`;
    const avg = typeof d.avg_rating !== 'undefined' ? d.avg_rating : 0;
    const reviewsCount = typeof d.reviews_count !== 'undefined' ? d.reviews_count : 0;
    const starsHtml = renderStarsHTML(avg, reviewsCount);
    const actionsHtml = isAdmin ? `<div class="actions admin-actions"><button class="edit-btn" data-id="${encodeURIComponent(d.id)}">Editar</button><button class="delete-btn" data-id="${encodeURIComponent(d.id)}">Excluir</button><a class="view-btn" href="ver_destino.php?id=${encodeURIComponent(d.id)}">Ver mais</a></div>` : `<div class="actions"><a class="view-btn" href="ver_destino.php?id=${encodeURIComponent(d.id)}">Ver mais</a></div>`;
    return `<div class="destino" data-id="${escapeHtml(String(d.id))}">${img}<h3>${escapeHtml(d.titulo)}</h3>${descricaoHtml}<div class="meta">${disponibilidade}<span class="price">${preco}</span></div><div style="margin-top:8px">${starsHtml}<div style="color:var(--muted);font-size:12px;margin-top:4px">${reviewsCount} ${reviewsCount === 1 ? 'avaliação' : 'avaliações'}</div></div>${actionsHtml}</div>`;
  }).join('');
  lista.innerHTML = html;
  initDescriptionToggles(lista);
  if (clientUser && Number(clientUser.is_admin) === 1) {
    document.querySelectorAll('.edit-btn').forEach(b => b.addEventListener('click', onEdit));
    document.querySelectorAll('.delete-btn').forEach(b => b.addEventListener('click', onDelete));
  }
}

function renderPagination(totalPages, currentPage) {
  const nav = document.getElementById('pagination'); if (!nav) return; nav.innerHTML = '';
  const prev = document.createElement('button'); prev.textContent = '«'; prev.disabled = currentPage <= 1; prev.addEventListener('click', () => { FILTER_STATE.page = currentPage - 1; refreshGrid(); }); nav.appendChild(prev);
  const maxButtons = 5;
  let start = Math.max(1, currentPage - 2);
  let end = Math.min(totalPages, start + maxButtons - 1);
  if (end - start < maxButtons - 1) start = Math.max(1, end - maxButtons + 1);
  for (let i = start; i <= end; i++) {
    const btn = document.createElement('button'); btn.textContent = String(i);
    if (i === currentPage) btn.classList.add('active');
    btn.addEventListener('click', () => { FILTER_STATE.page = i; refreshGrid(); });
    nav.appendChild(btn);
  }
  const next = document.createElement('button'); next.textContent = '»'; next.disabled = currentPage >= totalPages; next.addEventListener('click', () => { FILTER_STATE.page = currentPage + 1; refreshGrid(); }); nav.appendChild(next);
}

async function loadListData() {
  const lista = document.getElementById('lista-destinos');
  if (lista) lista.innerHTML = '<div class="msg-area">Carregando...</div>';
  try {
    const res = await fetch(`${apiBase}/list_destino.php`);
    const json = await res.json();
    if (!json.success) { ALL_DESTINOS = []; if (lista) lista.innerHTML = '<div class="msg-area">Erro ao carregar destinos.</div>'; return; }
    ALL_DESTINOS = json.data || [];
    const sel = document.getElementById('filterCountry');
    if (sel) {
      const unique = {};
      ALL_DESTINOS.forEach(d => { const k = (d.localizacao || '').trim(); if (k) unique[k] = true; });
      const keys = Object.keys(unique).sort();
      sel.innerHTML = '<option value="">Todos os locais</option>' + keys.map(k => `<option value="${escapeHtml(k)}">${escapeHtml(k)}</option>`).join('');
    }
    FILTER_STATE.page = 1;
    refreshGrid();
  } catch (err) {
    console.error(err);
    if (lista) lista.innerHTML = '<div class="msg-area">Erro ao carregar destinos.</div>';
  }
}

function refreshGrid() {
  const { items, total, totalPages, page } = applyFiltersAndPaginate();
  renderGrid(items);
  renderPagination(totalPages, page);
}

function bindFilterControls() {
  const search = document.getElementById('searchText');
  const country = document.getElementById('filterCountry');
  const priceMin = document.getElementById('priceMin');
  const priceMax = document.getElementById('priceMax');
  const perPageEl = document.getElementById('perPage');
  const resetBtn = document.getElementById('btnFilterReset');
  if (search) search.addEventListener('input', (e) => { FILTER_STATE.q = e.target.value; FILTER_STATE.page = 1; refreshGrid(); });
  if (country) country.addEventListener('change', (e) => { FILTER_STATE.country = e.target.value; FILTER_STATE.page = 1; refreshGrid(); });
  if (priceMin) priceMin.addEventListener('input', (e) => { const v = e.target.value; FILTER_STATE.priceMin = v === '' ? null : Number(v); FILTER_STATE.page = 1; refreshGrid(); });
  if (priceMax) priceMax.addEventListener('input', (e) => { const v = e.target.value; FILTER_STATE.priceMax = v === '' ? null : Number(v); FILTER_STATE.page = 1; refreshGrid(); });
  if (perPageEl) perPageEl.addEventListener('change', (e) => { FILTER_STATE.perPage = Number(e.target.value); FILTER_STATE.page = 1; refreshGrid(); });
  if (resetBtn) resetBtn.addEventListener('click', () => {
    FILTER_STATE.q = ''; FILTER_STATE.country = ''; FILTER_STATE.priceMin = null; FILTER_STATE.priceMax = null;
    FILTER_STATE.perPage = Number(document.getElementById('perPage')?.value || 6); FILTER_STATE.page = 1;
    if (search) search.value = ''; if (country) country.value = ''; if (priceMin) priceMin.value = ''; if (priceMax) priceMax.value = '';
    refreshGrid();
  });
}

function onEdit(e) {
  const id = e.currentTarget.getAttribute('data-id');
  fetch(`${apiBase}/get_destino.php?id=${id}`).then(r => r.json()).then(json => {
    if (!json.success) { alert('Erro ao buscar destino'); return; }
    const d = json.data;
    const form = document.getElementById('destino-form');
    form.querySelector('#titulo').value = d.titulo || '';
    form.querySelector('#descricao').value = d.descricao || '';
    form.querySelector('#preco').value = d.preco || '';
    form.querySelector('#localizacao').value = d.localizacao || '';
    form.querySelector('#dest-id').value = d.id || '';
    document.getElementById('preview').innerHTML = d.imagem ? `<img src="image/${d.imagem}" alt="" style="max-width:200px">` : '';
    document.getElementById('form-container').style.display = 'flex';
    document.body.classList.add('modal-open');
  }).catch(err => { console.error(err); alert('Erro ao buscar destino'); });
}

function onDelete(e) {
  if (!confirm('Confirma exclusão deste destino?')) return;
  const id = e.currentTarget.getAttribute('data-id');
  const fd = new FormData(); fd.append('csrf_token', document.querySelector('input[name="csrf_token"]') ? document.querySelector('input[name="csrf_token"]').value : ''); fd.append('id', id);
  fetch(`${apiBase}/delete_destino.php`, { method: 'POST', body: fd }).then(r => r.json()).then(json => {
    if (!json.success) { alert(json.error || 'Erro ao excluir'); return; }
    loadListData();
  }).catch(err => { console.error(err); alert('Erro ao excluir destino'); });
}

document.addEventListener('DOMContentLoaded', () => {
  const btnNovo = document.getElementById('btn-novo');
  const cancelBtn = document.getElementById('cancel-btn');
  const formContainer = document.getElementById('form-container');
  const form = document.getElementById('destino-form');
  const modal = document.getElementById('auth-modal');
  const tabBtns = Array.from(document.querySelectorAll('.tab-btn'));

  function setupAuthModalHandlers() {
    if (!modal) return;
    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const t = btn.getAttribute('data-tab');
        document.querySelectorAll('.auth-form').forEach(f => f.classList.toggle('active', f.id === `form-${t}`));
        const ai = document.querySelector(`#form-${t} input`);
        if (ai) ai.focus();
      });
    });
    const formLogin = document.getElementById('form-login');
    if (formLogin) {
      formLogin.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = (document.getElementById('login-email')?.value || '').trim();
        const pass = (document.getElementById('login-pass')?.value || '').trim();
        if (!email || !pass) { alert('Preencha email e senha.'); return; }
        try {
          const data = await postJson(window.API_BASE + '/login.php', { email, password: pass });
          if (data && data.success) {
            const user = data.user || { name: email.split('@')[0], email };
            onAuthSuccess(user);
          } else {
            alert(data.message || 'Erro ao logar.');
          }
        } catch (err) {
          console.error('[destinos.js] erro login', err);
          alert('Erro de conexão com o servidor. Veja console.');
        }
      });
    }
    const formRegister = document.getElementById('form-register');
    if (formRegister) {
      formRegister.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = (document.getElementById('reg-name')?.value || '').trim();
        const email = (document.getElementById('reg-email')?.value || '').trim();
        const pass = (document.getElementById('reg-pass')?.value || '').trim();
        if (!name || !email || !pass) { alert('Preencha todos os campos para registrar.'); return; }
        try {
          const data = await postJson(window.API_BASE + '/register.php', { name, email, password: pass });
          if (data && data.success) {
            const user = data.user || { name, email };
            onAuthSuccess(user);
          } else {
            alert(data.message || 'Erro ao registrar.');
          }
        } catch (err) {
          console.error('[destinos.js] erro register', err);
          alert('Erro de conexão com o servidor.');
        }
      });
    }
  }

  try { bindFilterControls(); } catch (e) { /* ignore */ }

  if (btnNovo && formContainer && form) {
    btnNovo.addEventListener('click', () => {
      if (!clientUser) { showAuthModal(); return; }
      formContainer.style.display = 'flex';
      document.body.classList.add('modal-open');
      form.reset();
      document.getElementById('preview').innerHTML = '';
      form.querySelector('#dest-id').value = '';
      document.getElementById('msg-area').innerText = '';
      const firstInput = form.querySelector('input, textarea');
      if (firstInput) firstInput.focus();
    });
  }

  if (cancelBtn && formContainer) {
    cancelBtn.addEventListener('click', () => {
      formContainer.style.display = 'none';
      document.body.classList.remove('modal-open');
    });
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const id = fd.get('id');
      const url = id ? `${apiBase}/update_destino.php` : `${apiBase}/create_destino.php`;
      const res = await fetch(url, { method: 'POST', body: fd });
      const json = await res.json();
      if (!json.success) {
        document.getElementById('msg-area').innerText = (json.error || (json.errors && json.errors.join(', '))) || 'Erro';
        return;
      }
      await loadListData();
      form.reset();
      formContainer.style.display = 'none';
      document.body.classList.remove('modal-open');
    });
  }

  setupAuthModalHandlers();

  try { initDescriptionToggles(document); } catch (e) {}

  if (!clientUser) {
    showAuthModal();
  } else {
    updateNavWithUser(clientUser);
    setBtnNovoVisibility();
    loadListData();
  }
});

(function setClientHeaderRandom() {
  const infoEl = document.getElementById('admin_info');
  if (!infoEl) return;
  const options = [
    'Descubra os melhores destinos e planeje sua próxima viagem.',
    'Explore nosso catálogo e encontre sua próxima aventura.',
    'Encontre pacotes, experiências e dicas para viajar com tranquilidade.',
    'Veja os destinos em destaque e garanta sua reserva.',
    'Inspire-se: destinos imperdíveis para sua próxima viagem.',
    'Navegue pelos destinos e escolha a experiência ideal para você.',
    'Explore, inspire-se e comece a planejar suas próximas férias.'
  ];
  infoEl.textContent = options[Math.floor(Math.random() * options.length)];
})();
