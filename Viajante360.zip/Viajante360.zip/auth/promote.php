<?php

session_start();
header('Content-Type: application/json; charset=utf-8');


$ADMIN_SECRET = 'SEGREDOTOPCRUDRGLL';    
$dbHost = '127.0.0.1';
$dbUser = 'root';
$dbPass = '';
$dbName = 'viajante360';

$provided = $_SERVER['HTTP_X_ADMIN_SECRET'] ?? '';

if ($provided !== $ADMIN_SECRET) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Segredo inválido']);
    exit;
}

$user = $_SESSION['user'] ?? null;
if (!$user || !isset($user['id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado']);
    exit;
}

$uid = (int)$user['id'];

$mysqli = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
if ($mysqli->connect_errno) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao conectar ao banco']);
    exit;
}

$stmt = $mysqli->prepare("UPDATE users SET is_admin = 1 WHERE id = ?");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao preparar query']);
    exit;
}
$stmt->bind_param('i', $uid);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    $q = $mysqli->prepare("SELECT id, name, email, is_admin FROM users WHERE id = ?");
    $q->bind_param('i', $uid);
    $q->execute();
    $res = $q->get_result()->fetch_assoc();

    $_SESSION['user'] = array_merge($_SESSION['user'], $res);

    echo json_encode(['success' => true, 'message' => 'Usuário promovido a admin', 'user' => $res]);
} else {
    echo json_encode(['success' => false, 'message' => 'Nada alterado (já admin ou usuário não encontrado)']);
}
