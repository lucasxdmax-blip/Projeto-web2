<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';

if (empty($_SESSION['user']['id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Usuário não autenticado.']);
    exit;
}

$user_id = (int)$_SESSION['user']['id'];

try {
    $stmt = $pdo->prepare("
        SELECT 
            r.id, 
            r.data_reserva, 
            r.status,
            r.created_at,
            d.titulo as destino_titulo,
            d.localizacao as destino_localizacao,
            d.imagem as destino_imagem
        FROM reservas r
        JOIN destinos d ON r.destino_id = d.id
        WHERE r.user_id = ?
        ORDER BY r.data_reserva ASC
    ");
    $stmt->execute([$user_id]);
    $reservas = $stmt->fetchAll();

    echo json_encode(['success' => true, 'data' => $reservas]);
} catch (Exception $e) {
    http_response_code(500);
    @file_put_contents(__DIR__ . '/../auth/debug.log', '['.date('c')."] list_reservas error: ".$e->getMessage()."\n", FILE_APPEND);
    echo json_encode(['success' => false, 'error' => 'Erro ao listar reservas.']);
}

//Feito por Gustavo.