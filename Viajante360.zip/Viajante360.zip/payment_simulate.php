<?php
// payment_simulate.php - apenas para testes locais
if (session_status() === PHP_SESSION_NONE) session_start();
$token = $_GET['token'] ?? '';
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Simular Pagamento</title></head>
<body>
<h2>Simular Pagamento</h2>
<p>Token: <strong><?=htmlspecialchars($token,ENT_QUOTES,'UTF-8')?></strong></p>
<button id="pay">Simular pagamento (confirmar)</button>
<div id="result"></div>

<script>
document.getElementById('pay').addEventListener('click', function(){
  fetch('reservas_api/confirm_payment.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ token: '<?=addslashes($token)?>' })
  }).then(r=>r.json()).then(j=>{
    document.getElementById('result').innerText = JSON.stringify(j, null, 2);
    if (j.success) {
      window.location.href = "reserva.php?reserva_id=" + j.reserva_id + "&status=paid";
    }
  }).catch(err=>{ document.getElementById('result').innerText = err; });
});
</script>
</body>
</html>
