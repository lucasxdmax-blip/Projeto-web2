<?php
require_once 'config.php';

function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

function ensure_csrf() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['csrf_token'];
}

function validate_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}

$user = $_SESSION['user'] ?? null;
$is_admin = isset($user['is_admin']) && (int)$user['is_admin'] === 1;
$user_id = $user['id'] ?? null;

$flash_success = $_SESSION['flash_success'] ?? null;
$flash_error = $_SESSION['flash_error'] ?? null;
unset($_SESSION['flash_success'], $_SESSION['flash_error']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    header('Location: destinos.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    $token = $_POST['csrf_token'] ?? '';
    if (!validate_csrf($token)) {
        $_SESSION['flash_error'] = 'Token CSRF inválido. Tente novamente.';
        header('Location: ver_destino.php?id=' . $id);
        exit;
    }

    if ($action === 'delete_destino') {
        if (!$is_admin) {
            $_SESSION['flash_error'] = 'Ação permitida apenas para administradores.';
            header('Location: ver_destino.php?id=' . $id);
            exit;
        }

        $destino_id = intval($_POST['destino_id'] ?? 0);
        if ($destino_id <= 0 || $destino_id !== $id) {
            $_SESSION['flash_error'] = 'ID inválido para exclusão.';
            header('Location: ver_destino.php?id=' . $id);
            exit;
        }

        try {
            $stmt = $pdo->prepare('SELECT imagem FROM destinos WHERE id = ? LIMIT 1');
            $stmt->execute([$destino_id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $imagemNome = $row['imagem'] ?? null;

            $stmt = $pdo->prepare('DELETE FROM destinos WHERE id = ?');
            $stmt->execute([$destino_id]);

            if ($imagemNome) {
                if (!preg_match('#^https?://#i', $imagemNome)) {
                    $filePath = __DIR__ . '/image/' . $imagemNome;
                    if (file_exists($filePath)) @unlink($filePath);
                }
            }

            $_SESSION['flash_success'] = 'Destino excluído.';
            header('Location: destinos.php');
            exit;
        } catch (Exception $e) {
            error_log('Erro delete destino: ' . $e->getMessage());
            $_SESSION['flash_error'] = 'Erro ao excluir destino.';
            header('Location: ver_destino.php?id=' . $id);
            exit;
        }
    }

    if ($action === 'add_review') {
        if (!$user) {
            $_SESSION['flash_error'] = 'Você precisa entrar para enviar uma avaliação.';
            header('Location: ver_destino.php?id=' . $id);
            exit;
        }

        $rating = intval($_POST['rating'] ?? 0);
        $comment = trim((string)($_POST['comment'] ?? ''));

        if ($rating < 1 || $rating > 5) {
            $_SESSION['flash_error'] = 'Avaliação inválida (1 a 5).';
            header('Location: ver_destino.php?id=' . $id);
            exit;
        }

        try {
            $stmt = $pdo->prepare('INSERT INTO reviews (destino_id, user_id, user_name, rating, comment, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
            $user_name = $user['name'] ?? ($user['email'] ?? 'Usuário');
            $stmt->execute([$id, $user_id ?: null, $user_name, $rating, $comment]);
            $_SESSION['flash_success'] = 'Avaliação enviada com sucesso.';
            header('Location: ver_destino.php?id=' . $id);
            exit;
        } catch (Exception $e) {
            error_log('Erro add review: ' . $e->getMessage());
            $_SESSION['flash_error'] = 'Erro ao enviar avaliação.';
            header('Location: ver_destino.php?id=' . $id);
            exit;
        }
    }

    $_SESSION['flash_error'] = 'Ação inválida.';
    header('Location: ver_destino.php?id=' . $id);
    exit;
}

try {
    $stmt = $pdo->prepare('SELECT id, titulo, descricao, preco, localizacao, imagem, disponivel, created_at FROM destinos WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $dest = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$dest) {
        $_SESSION['flash_error'] = 'Destino não encontrado.';
        header('Location: destinos.php');
        exit;
    }
} catch (Exception $e) {
    die('Erro ao buscar destino: ' . e($e->getMessage()));
}

$titulo = $dest['titulo'];
$descricao = $dest['descricao'];
$preco = $dest['preco'];
$localizacao = $dest['localizacao'];
$imagem = $dest['imagem'];
$disponivel = (int)$dest['disponivel'] === 1;

$csrf = ensure_csrf();

try {
    $stmt = $pdo->prepare('SELECT COUNT(*) as cnt, COALESCE(AVG(rating),0) as avg_rating FROM reviews WHERE destino_id = ?');
    $stmt->execute([$id]);
    $stat = $stmt->fetch(PDO::FETCH_ASSOC);
    $reviews_count = (int)($stat['cnt'] ?? 0);
    $avg_rating = $stat['avg_rating'] !== null ? (float)$stat['avg_rating'] : 0.0;

    $stmt = $pdo->prepare('SELECT id, user_name, rating, comment, created_at FROM reviews WHERE destino_id = ? ORDER BY created_at DESC');
    $stmt->execute([$id]);
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $reviews_count = 0;
    $avg_rating = 0;
    $reviews = [];
}

$apiBase = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/destinos_api';
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title><?= e($titulo) ?> — Viajante360</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/ver_destino.css">
  <link rel="shortcut icon" href="image/logo.png" type="image/x-icon">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
  <script>
      window.VI360_USER = <?= json_encode($user, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
      window.API_BASE = "<?= htmlspecialchars($apiBase ?? '', ENT_QUOTES) ?>";
  </script>
</head>
<body>
  <header class="site-header">
    <div class="brand">
      <img src="image/logo.png" alt="Viajante 360" class="logo" id="brand-logo">
      <div>
        <h1>Viajante 360</h1>
        <p>Viagens com atitude</p>
      </div>
    <nav id="main-nav" class="main-nav" aria-label="Navegação principal">
      <a href="index.php">Início</a>
      <a href="destinos.php" class="active">Destinos</a>
      <a href="reserva.php">Reservas</a>
      <a href="#sobre">Sobre</a>
      <a class="cta" href="#reservar">User</a>
    </nav>
   </div>
  </header>

  <div id="auth-modal" class="auth-modal" aria-hidden="true" role="dialog" aria-modal="true">
    <div class="auth-panel">
      <div class="auth-header">
        <img src="image/logo.png" alt="Viajante 360" class="auth-logo">
        <div>
          <h2>Bem-vindo ao Viajante 360</h2>
          <p>Crie sua conta ou entre para desbloquear o acesso.</p>
        </div>
      </div>
      <div class="auth-tabs">
        <button type="button" class="tab-btn active" data-tab="login">Entrar</button>
        <button type="button" class="tab-btn" data-tab="register">Registrar</button>
      </div>
      <div class="auth-body">
        <form id="form-login" class="auth-form active" autocomplete="off">
          <label>Email</label>
          <input type="email" id="login-email" required placeholder="seu@exemplo.com">
          <label>Senha</label>
          <input type="password" id="login-pass" required placeholder="********">
          <button type="submit" class="btn-auth">Entrar</button>
        </form>
        <form id="form-register" class="auth-form" autocomplete="off">
          <label>Nome</label>
          <input type="text" id="reg-name" required placeholder="Seu nome">
          <label>Email</label>
          <input type="email" id="reg-email" required placeholder="seu@exemplo.com">
          <label>Senha</label>
          <input type="password" id="reg-pass" required placeholder="********">
          <button type="submit" class="btn-auth">Registrar</button>
        </form>
      </div>
      <div class="auth-footer">
        <small>É obrigatório — você só poderá navegar após registrar-se ou entrar.</small>
      </div>
    </div>
  </div>

  <main class="container">
    <?php if ($flash_success): ?>
      <div class="notice success"><?= e($flash_success) ?></div>
    <?php endif; ?>
    <?php if ($flash_error): ?>
      <div class="notice error"><?= e($flash_error) ?></div>
    <?php endif; ?>

    <div class="detail-grid" role="region" aria-label="Detalhes do destino">
      <div class="left">
        <div class="thumb">
          <?php if (!empty($imagem)): ?>
                <?php $imgSrc = preg_match('#^https?://#i', $imagem) ? $imagem : ('image/' . $imagem); ?>
                <img src="<?= e($imgSrc) ?>" alt="<?= e($titulo) ?>" class="cover-img">
          <?php else: ?>
            <div style="width:100%;height:320px;background:#f0f0f0;border-radius:10px;display:flex;align-items:center;justify-content:center">Sem imagem</div>
          <?php endif; ?>
        </div>

        <h1 style="margin-top:12px;"><?= e($titulo) ?></h1>

        <div style="margin-top:8px;">
          <div><?= e($localizacao ?: 'Local não informado') ?></div>
          <div style="margin-top:8px;">
            <span class="price"><?= $preco !== null && $preco !== '' ? 'R$ ' . number_format($preco, 2, ',', '.') : 'Preço sob consulta' ?></span>
            <span class="badge <?= $disponivel ? 'available' : 'unavailable' ?>"><?= $disponivel ? 'Disponível' : 'Indisponível' ?></span>
          </div>
        </div>

        <section style="margin-top:14px;">
          <h3>Descrição</h3>
          <div class="descricao-wrapper">
            <div id="descricaoBox" class="descricao-box" role="region" aria-label="Descrição do destino">
              <div class="descricao-content"><?= nl2br(e($descricao)) ?></div>
            </div>
            <button id="toggle-desc" class="btn ghost desc-toggle" type="button" data-expanded="false" aria-expanded="false" style="margin-top:10px;">
              Mostrar mais
            </button>
          </div>
        </section>

        <section style="margin-top:18px;">
          <h3>Avaliações</h3>
          <div class="rating-row">
            <div class="stars-inline" aria-hidden="true">
              <?php
                $rounded = round($avg_rating * 2) / 2;
                for ($i = 1; $i <= 5; $i++) {
                    $filled = $i <= floor($rounded) ? 'filled' : ($i == ceil($rounded) && ($rounded % 1 !== 0) ? 'filled' : '');
                    echo "<span class=\"star {$filled}\">★</span>";
                }
              ?>
            </div>
            <div style="margin-left:8px;font-weight:800;"><?= $reviews_count ? number_format($avg_rating, 1) : '' ?></div>
            <div style="margin-left:8px;color:var(--muted)"><?= $reviews_count ? "({$reviews_count} " . ($reviews_count === 1 ? 'avaliação' : 'avaliações') . ')' : '(sem avaliações)' ?></div>
          </div>

          <div class="reviews" id="reviews-list" style="margin-top:12px;">
            <?php if (count($reviews) === 0): ?>
              <div class="msg-area">Seja o primeiro a avaliar este destino.</div>
            <?php else: ?>
              <?php foreach ($reviews as $r): ?>
                <div class="review">
                  <div class="meta">
                    <div class="who"><?= e($r['user_name'] ?: 'Anônimo') ?></div>
                    <div class="when" style="color:var(--muted);margin-left:8px;font-size:13px"><?= e($r['created_at']) ?></div>
                  </div>
                  <div style="margin-top:6px;">
                    <?php
                      $rr = intval($r['rating']);
                      for ($s=1;$s<=5;$s++) {
                        echo '<span class="star' . ($s <= $rr ? ' filled' : '') . '">★</span>';
                      }
                    ?>
                  </div>
                  <?php if (trim((string)$r['comment']) !== ''): ?>
                    <div class="comment" style="margin-top:8px;color:var(--muted)"><?= nl2br(e($r['comment'])) ?></div>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </section>
      </div>

      <div class="right">
        <div style="border-radius:10px;padding:12px;border:1px solid rgba(255,255,255,0.03);background:rgba(255,255,255,0.01)">
          <h4>Suas opções</h4>
          <div style="margin-top:10px;">
            <?php if ($is_admin): ?>
              <a href="editar_destino.php?id=<?= (int)$id ?>" class="btn ghost" style="margin-right:8px">Editar</a>
              <form method="post" style="display:inline" onsubmit="return confirm('Confirma exclusão deste destino?');">
                <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">
                <input type="hidden" name="action" value="delete_destino">
                <input type="hidden" name="destino_id" value="<?= (int)$id ?>">
                <button type="submit" class="btn ghost">Excluir</button>
              </form>
              <a href="destinos.php" class="btn ghost" style="margin-left:8px">Voltar</a>
            <?php else: ?>
              <form id="reserve-form" method="post" action="#" onsubmit="return false;" style="display:inline-block;">
                <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">
                <input type="hidden" name="destino_id" value="<?= (int)$id ?>">
                <label style="display:inline-block;margin-right:8px">Pessoas:
                  <input type="number" name="guests" id="guests" value="1" min="1" style="width:70px;margin-left:6px">
                </label>
                <button id="btn-reserve" class="btn primary" <?= !$disponivel ? 'disabled' : '' ?>>Reservar</button>
              </form>
              <a href="destinos.php" class="btn ghost" style="margin-left:8px">Voltar</a>
            <?php endif; ?>
          </div>

          <hr style="margin:12px 0;border-color:rgba(255,255,255,0.03)">

          <form method="post" id="review-form">
            <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">
            <input type="hidden" name="action" value="add_review">
            <input type="hidden" name="rating" id="rating-input" value="0">
            <input type="hidden" name="destino_id" value="<?= (int)$id ?>">

            <label style="display:block;color:var(--muted);margin-bottom:6px">Sua nota</label>
            <div id="star-input" class="stars-inline" aria-label="Selecione nota (1 a 5)">
              <span class="star" data-value="1" title="1 estrela">★</span>
              <span class="star" data-value="2" title="2 estrelas">★</span>
              <span class="star" data-value="3" title="3 estrelas">★</span>
              <span class="star" data-value="4" title="4 estrelas">★</span>
              <span class="star" data-value="5" title="5 estrelas">★</span>
            </div>

            <label style="display:block;margin-top:10px;color:var(--muted)">Comentário</label>
            <textarea name="comment" id="review-comment" placeholder="Compartilhe sua experiência..." style="width:100%;min-height:100px;padding:8px;border-radius:8px;background:#0f1415;color:var(--text);border:1px solid rgba(255,255,255,0.03)"></textarea>

            <div style="margin-top:10px;display:flex;gap:8px;">
              <button type="submit" class="btn primary">Enviar avaliação</button>
              <button type="button" id="btn-clear-review" class="btn ghost">Limpar</button>
            </div>
          </form>
        </div>
      </div>
    </div>

  </main>

  <footer>
        <div>© <strong>Mígrasoft</strong> · 2025</div>
        <div class="social">
            <a href="#" title="Instagram">IG</a>
            <a href="#" title="Twitter">TW</a>
            <a href="#" title="Contato">📱</a>
        </div>
  </footer>

  <div id="payment-modal" style="display:none;position:fixed;inset:0;z-index:9999;align-items:center;justify-content:center;background:rgba(0,0,0,0.6);">
    <div style="width:380px;background:#0b0d0e;padding:18px;border-radius:12px;border:1px solid rgba(255,255,255,0.04);text-align:left;color:var(--text);">
      <h3 style="margin-top:0">Pagamento (Simulado)</h3>
      <p id="pm-desc">Efetue o pagamento simulado para confirmar sua reserva.</p>
      <div style="margin:10px 0">
        <label>Nome no cartão</label>
        <input id="pm-name" type="text" placeholder="SEU NOME" style="width:100%;padding:8px;border-radius:6px;margin-top:6px">
      </div>
      <div style="display:flex;gap:8px">
        <div style="flex:2">
          <label>Número</label>
          <input id="pm-number" type="text" placeholder="0000 0000 0000 0000" style="width:100%;padding:8px;border-radius:6px;margin-top:6px">
        </div>
        <div style="flex:1">
          <label>CVV</label>
          <input id="pm-cvv" type="text" placeholder="123" style="width:100%;padding:8px;border-radius:6px;margin-top:6px">
        </div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px">
        <button id="pm-cancel" class="btn ghost" type="button">Cancelar</button>
        <button id="pm-pay" class="btn primary" type="button">Pagar (simular)</button>
      </div>
      <div id="pm-msg" style="margin-top:10px;color:var(--muted);font-size:13px"></div>
    </div>
  </div>

  <script>
    window.FORCE_AUTH_MODAL = <?= (isset($_GET['logged_out']) && $_GET['logged_out'] == '1') ? 'true' : 'false' ?>;
  </script>
  <script src="js/ver_destino.js" defer></script>
</body>
</html>
