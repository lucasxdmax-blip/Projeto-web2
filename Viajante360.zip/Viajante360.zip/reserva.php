<?php
require_once 'config.php';
$user = $_SESSION['user'] ?? null;
$baseUrl = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$apiBase = $baseUrl . '/auth';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Reservas - Viajante 360</title>
    <link rel="shortcut icon" href="image/logo.png" type="image/x-icon">
    <link href="css/reserva.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <script>
      window.VI360_USER = <?= json_encode($user, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
      window.API_BASE = "<?= htmlspecialchars($apiBase, ENT_QUOTES) ?>";
    </script>
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <div class="brand">
        <img src="image/logo.png" alt="Viajante 360" class="logo" id="brand-logo">
        <div>
          <h1>Viajante 360</h1>
          <p>Viagens com atitude</p>
        </div>
      </div>
      <nav id="main-nav" class="main-nav" aria-label="Navegação principal">
        <a href="index.php">Início</a>
        <a href="destinos.php">Destinos</a>
        <a href="reserva.php" class="active">Reservas</a>
        <a href="sobre.php">Sobre</a>
        <a class="cta cta-user" href="#">User</a>
      </nav>
    </div>
  </header>

  <main class="container">
      <div class="header-top">
        <h1>Minhas Reservas</h1>
        <p class="muted" id="reserva_info">Gerencie suas viagens e agende novas aventuras.</p>
      </div>

      <section class="reserva-grid">
        <div class="reserva-form-panel">
          <h3>Agendar nova viagem</h3>
          <form id="form-reserva">
            <label for="destino-select">Selecione o destino</label>
            <select id="destino-select" name="destino_id" required>
              <option value="">Carregando destinos...</option>
            </select>

            <label for="data-reserva">Escolha a data</label>
            <input type="date" id="data-reserva" name="data_reserva" required>

            <div style="margin-top:12px; display:flex; gap:8px; align-items:center;">
              <button type="submit" class="btn-submit">Confirmar Reserva</button>
              <button type="button" id="btn-simulate-pay" class="btn-ghost">Simular Pagamento</button>
            </div>
          </form>
          <div id="reserva-msg" class="msg-area"></div>
        </div>

        <div id="lista-reservas-container" class="reserva-list-panel">
          <h3>Viagens agendadas</h3>
          <div id="lista-reservas" aria-live="polite">
            <p>Faça login para ver suas reservas.</p>
          </div>
        </div>
      </section>
  </main>

  <div id="auth-modal" class="auth-modal" aria-hidden="true" role="dialog" aria-modal="true" style="display: none;">
    <div class="auth-panel">
      <div class="auth-header">
        <img src="image/logo.png" alt="Viajante 360" class="auth-logo">
        <div>
          <h2>Bem-vindo ao Viajante 360</h2>
          <p>Crie sua conta ou entre para ver suas reservas.</p>
        </div>
      </div>
      <div class="auth-tabs">
        <button type="button" class="tab-btn active" data-tab="login">Entrar</button>
        <button type="button" class="tab-btn" data-tab="register">Registrar</button>
      </div>
      <div class="auth-body">
        <form id="form-login" class="auth-form active" autocomplete="off">
          <label>Email</label>
          <input type="email" id="login-email" required placeholder="seu@exemplo.com">
          <label>Senha</label>
          <input type="password" id="login-pass" required placeholder="********">
          <button type="submit" class="btn-auth">Entrar</button>
        </form>
        <form id="form-register" class="auth-form" autocomplete="off">
          <label>Nome</label>
          <input type="text" id="reg-name" required placeholder="Seu nome">
          <label>Email</label>
          <input type="email" id="reg-email" required placeholder="seu@exemplo.com">
          <label>Senha</label>
          <input type="password" id="reg-pass" required placeholder="********">
          <button type="submit" class="btn-auth">Registrar</button>
        </form>
      </div>
    </div>
  </div>

  <div id="payment-modal" class="auth-modal" aria-hidden="true" role="dialog" aria-modal="true" style="display:none;">
    <div class="auth-panel" style="max-width:420px;">
      <h3>Simulação de pagamento</h3>
      <p id="pay-summary" style="margin-top:8px;color:var(--muted)">Resumo da compra</p>
      <div style="margin-top:12px;display:flex;gap:8px;justify-content:flex-end;">
        <button id="btn-pay-cancel" class="btn-ghost">Cancelar</button>
        <button id="btn-pay-ok" class="btn-primary">Pagar (simulação)</button>
      </div>
    </div>
  </div>

   <footer>
        <div class="container">
            <span>© <strong>Mígrasoft</strong> · 2025</span>
            <div class="social">
                <a href="#" title="Instagram">IG</a>
                <a href="#" title="Twitter">TW</a>
                <a href="#" title="Contato">📱</a>
            </div>
        </div>
    </footer>
    <script>
      window.FORCE_AUTH_MODAL = <?= (isset($_GET['logged_out']) && $_GET['logged_out'] == '1') ? 'true' : 'false' ?>;
    </script>
    <script src="js/reserva.js" defer></script>
</body>
</html>
