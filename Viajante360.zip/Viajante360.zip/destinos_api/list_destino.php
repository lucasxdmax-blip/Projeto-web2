<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';

try {
    $sql = "
      SELECT d.id, d.titulo, d.descricao, d.preco, d.localizacao, d.imagem, d.disponivel,
             COALESCE(r.avg_rating, 0) AS avg_rating,
             COALESCE(r.cnt, 0) AS reviews_count
      FROM destinos d
      LEFT JOIN (
        SELECT destino_id, AVG(rating) AS avg_rating, COUNT(*) AS cnt
        FROM reviews
        GROUP BY destino_id
      ) r ON r.destino_id = d.id
      ORDER BY d.created_at DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $data = array_map(function($r) {
      return [
        'id' => (int)$r['id'],
        'titulo' => $r['titulo'],
        'descricao' => $r['descricao'],
        'preco' => $r['preco'] === null ? null : (float)$r['preco'],
        'localizacao' => $r['localizacao'],
        'imagem' => $r['imagem'],
        'disponivel' => (int)$r['disponivel'],
        'avg_rating' => round((float)$r['avg_rating'], 2),
        'reviews_count' => (int)$r['reviews_count']
      ];
    }, $rows);

    echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro ao listar destinos.']);
    error_log('list_destino.php erro: ' . $e->getMessage());
    exit;
}
