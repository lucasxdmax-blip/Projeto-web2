<?php
session_start();

$user = $_SESSION['user'] ?? null;

$baseUrl = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$apiBase = $baseUrl . '/auth';

$currentFile = basename($_SERVER['SCRIPT_NAME']);
$destinosHref = ($currentFile === 'index.php') ? '#destinos' : 'destinos.php';
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Viajante 360</title>
    <link rel="shortcut icon" href="image/logo.png" type="image/x-icon">
    <link href="css/estilo.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@300;400;600&display=swap"
        rel="stylesheet">

    <script>
      window.VI360_USER = <?= json_encode($user, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
      window.API_BASE = "<?= htmlspecialchars($apiBase, ENT_QUOTES) ?>";
    </script>
</head>
<body>
    <header>
        <div class="brand">
            <img src="image/logo.png" alt="Viajante 360" class="logo" id="brand-logo">
            <div>
                <h1>Viajante 360</h1>
                <p>Viagens com atitude</p>
            </div>
        </div>

        <nav id="main-nav">
            <a href="#home" class="active">Início</a>
            <a href="destinos.php">Destinos</a>
            <a href="reserva.php">Reservas</a>
            <a href="sobre.php">Sobre</a>
            <a class="cta" href="#reservar">User</a>
        </nav>
    </header>

    <main>
        <section class="hero" id="home">
            <img src="image/banner.jpg" alt="Banner" class="Banner_1" id="banner-1">
            <div class="left">
                <div class="kicker">Momentos inesquecíveis • Experiências reais</div>
                <h2>Explore o mundo com atitude — viaje com estilo.</h2>
                <p>Experiências locais e reservas rápidas. Venha viajar com preços baixos sem perder a elegância e luxo para viajantes.</p>

                <div class="search-card">
                    <form class="search-row" action="#" method="get">
                        <input type="text" name="destino" placeholder="Para onde quer ir?" />
                        <input type="date" name="data" />
                        <button type="submit">Buscar</button>
                    </form>
                </div>
            </div>

            <aside class="search-card" style="display:flex;flex-direction:column;gap:12px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <strong>Ofertas rápidas</strong>
                    <small style="color:var(--muted)">Últimas 24h</small>
                </div>
                <div style="display:flex;flex-direction:column;gap:8px">
                    <div style="display:flex;justify-content:space-between"><span>São Paulo → Lisboa</span><strong>R$1.799</strong></div>
                    <div style="display:flex;justify-content:space-between"><span>Rio → Orlando</span><strong>R$2.199</strong></div>
                    <div style="display:flex;justify-content:space-between"><span>Salvador → Lisboa</span><strong>R$1.599</strong></div>
                </div>
                <a href="#destinos" class="cta" style="text-align:center">Ver todas</a>
            </aside>
        </section>

        <section id="destinos">
            <div style="padding:18px 28px 0 28px;display:flex;justify-content:space-between;align-items:center">
                <h2 style="margin:0">Destinos populares</h2>
            </div>

            <div class="grid">
                <article class="card">
                    <div class="thumb">✈️</div>
                    <h3>Lisboa, Portugal</h3>
                    <p>Cultura, gastronomia e clima ameno — perfeito para quem quer caminhar sem pressa.</p>
                </article>
                <article class="card">
                    <div class="thumb">🏖️</div>
                    <h3>Orlando, EUA</h3>
                    <p>Parques, diversão e roteiros familiares com opções de pacotes temáticos.</p>
                </article>
                <article class="card">
                    <div class="thumb">🏔️</div>
                    <h3>Bariloche, Argentina</h3>
                    <p>Neve, trilhas e paisagens espetaculares para quem ama aventura.</p>
                </article>
                <article class="card">
                    <div class="thumb">🌆</div>
                    <h3>Nova Iorque, EUA</h3>
                    <p>Vibração urbana, museus e gastronomia diversa — cidade que nunca dorme.</p>
                </article>
                <article class="card">
                    <div class="thumb">🏝️</div>
                    <h3>Fernando de Noronha, BR</h3>
                    <p>Praias e vida marinha preservada — ideal para mergulho e contato com a natureza.</p>
                </article>
                <article class="card">
                    <div class="thumb">🌄</div>
                    <h3>Machu Picchu, Peru</h3>
                    <p>História, cultura e uma das trilhas mais icônicas do continente.</p>
                </article>
            </div>
        </section>

        <section id="reservar" style="padding:28px">
            <div style="max-width:820px;margin:0 auto;background:var(--card);padding:18px;border-radius:12px">
                <h3>Reserve agora</h3>
                <p style="color:var(--muted);margin-top:0">Preencha os dados e aguarde nosso contato (formulário de demonstração).</p>
                <form style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                    <input placeholder="Seu nome" />
                    <input placeholder="Email" />
                    <select>
                        <option>Lisboa</option>
                        <option>Orlando</option>
                        <option>Bariloche</option>
                        <option>Noronha</option>
                    </select>
                    <input type="date" />
                    <textarea placeholder="Observações" style="grid-column:1/3;height:90px;padding:10px;border-radius:8px"></textarea>
                    <button style="grid-column:1/3;padding:12px;border-radius:10px;border:none;background:var(--accent);font-weight:700">Enviar pedido</button>
                </form>
            </div>
        </section>

        <section id="sobre" style="padding:28px">
            <div style="max-width:900px;margin:0 auto;color:var(--muted)">
                <h3>Sobre a Mígrasoft</h3>
                <p>Somos uma agência digital com alma moderna — unimos eficiência técnica, curadoria local e um visual moderno para transmitir energia e confiança.</p>
            </div>
        </section>
    </main>

    <div id="auth-modal" class="auth-modal" aria-hidden="true" role="dialog" aria-modal="true">
      <div class="auth-panel">
        <div class="auth-header">
          <img src="image/logo.png" alt="Viajante 360" class="auth-logo">
          <div>
            <h2>Bem-vindo ao Viajante 360</h2>
            <p>Crie sua conta ou entre para desbloquear o acesso.</p>
          </div>
        </div>

        <div class="auth-tabs">
          <button type="button" class="tab-btn active" data-tab="login">Entrar</button>
          <button type="button" class="tab-btn" data-tab="register">Registrar</button>
        </div>

        <div class="auth-body">
          <form id="form-login" class="auth-form active" autocomplete="off">
            <label>Email</label>
            <input type="email" id="login-email" required placeholder="seu@exemplo.com">
            <label>Senha</label>
            <input type="password" id="login-pass" required placeholder="********">
            <button type="submit" class="btn-auth">Entrar</button>
          </form>

          <form id="form-register" class="auth-form" autocomplete="off">
            <label>Nome</label>
            <input type="text" id="reg-name" required placeholder="Seu nome">
            <label>Email</label>
            <input type="email" id="reg-email" required placeholder="seu@exemplo.com">
            <label>Senha</label>
            <input type="password" id="reg-pass" required placeholder="********">
            <button type="submit" class="btn-auth">Registrar</button>
          </form>
        </div>

        <div class="auth-footer">
          <small>É obrigatório — você só poderá navegar após registrar-se ou entrar.</small>
        </div>
      </div>
    </div>

    <footer>
        <div>© <strong>Mígrasoft</strong> · 2025</div>
        <div class="social">
            <a href="#" title="Instagram">IG</a>
            <a href="#" title="Twitter">TW</a>
            <a href="#" title="Contato">📱</a>
        </div>
    </footer>
    <script>
    window.FORCE_AUTH_MODAL = <?= (isset($_GET['logged_out']) && $_GET['logged_out'] == '1') ? 'true' : 'false' ?>;
    </script>
    <script src="js/front.js" defer></script>
</body>
</html>
