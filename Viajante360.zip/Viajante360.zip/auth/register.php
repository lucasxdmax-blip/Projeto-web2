<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'Método não permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$name  = trim($input['name'] ?? '');
$email = trim($input['email'] ?? '');
$pass  = $input['password'] ?? '';

if ($name === '' || $email === '' || $pass === '') {
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Preencha todos os campos.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Email inválido.']);
    exit;
}

try {
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['success'=>false,'message'=>'Email já cadastrado.']);
        exit;
    }

    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)');
    $stmt->execute([$name, $email, $hash]);
    $stmt->execute([$userId]);

    $userId = (int)$pdo->lastInsertId();
    $stmt = $pdo->prepare('SELECT id, name, email, is_admin FROM users WHERE id = ? LIMIT 1');
    $userRow = $stmt->fetch();

$_SESSION['user'] = [
  'id' => (int)$userRow['id'],
  'name' => $userRow['name'],
  'email' => $userRow['email'],
  'is_admin' => !empty($userRow['is_admin']) ? 1 : 0
];

echo json_encode(['success'=>true,'message'=>'Registrado com sucesso','user'=>$_SESSION['user']]);

} catch (Exception $e) {
    http_response_code(500);
    @file_put_contents(__DIR__ . '/debug.log', '['.date('c')."] register error: ".$e->getMessage()."\n", FILE_APPEND);
    echo json_encode(['success'=>false,'message'=>'Erro interno no servidor.']);
    exit;
}
