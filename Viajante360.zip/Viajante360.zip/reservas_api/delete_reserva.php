<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';

if (empty($_SESSION['user']['id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Usuário não autenticado.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$reserva_id = $input['id'] ?? 0;
$user_id = (int)$_SESSION['user']['id'];

if ($reserva_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID da reserva inválido.']);
    exit;
}

try {
    // Garante que o usuário só pode deletar a própria reserva
    $stmt = $pdo->prepare("DELETE FROM reservas WHERE id = ? AND user_id = ?");
    $stmt->execute([$reserva_id, $user_id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Reserva cancelada com sucesso.']);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Reserva não encontrada ou não pertence ao usuário.']);
    }
} catch (Exception $e) {
    http_response_code(500);
    @file_put_contents(__DIR__ . '/../auth/debug.log', '['.date('c')."] delete_reserva error: ".$e->getMessage()."\n", FILE_APPEND);
    echo json_encode(['success' => false, 'error' => 'Erro interno ao cancelar reserva.']);
}
//Feito por Gustavo.