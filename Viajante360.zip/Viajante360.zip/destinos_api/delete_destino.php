<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/token_csrf.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido.']);
    exit;
}

$token = $_POST['csrf_token'] ?? '';
if (!validate_csrf_token($token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Token CSRF inválido.']);
    exit;
}

if (empty($_SESSION['user']) || !isset($_SESSION['user']['is_admin']) || (int)$_SESSION['user']['is_admin'] !== 1) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Ação permitida apenas para administradores.']);
    exit;
}

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID inválido.']);
    exit;
}

$stmt = $pdo->prepare("SELECT imagem FROM destinos WHERE id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();
if (!$row) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Destino não encontrado.']);
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM destinos WHERE id = ?");
    $stmt->execute([$id]);

    if ($row['imagem']) {
        $path = __DIR__ . '/../image/' . $row['imagem'];
        if (file_exists($path)) @unlink($path);
    }

    echo json_encode(['success' => true]);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro no servidor.']);
    exit;
}
