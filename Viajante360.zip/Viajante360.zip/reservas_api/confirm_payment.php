<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config.php';
if (!isset($pdo) && function_exists('pdo')) $pdo = pdo();
if (!isset($pdo)) {
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'DB não configurado']);
    exit;
}

$input = $_POST ?: json_decode(file_get_contents('php://input'), true) ?: [];
$token = $input['token'] ?? null;
$reserva_id = isset($input['reserva_id']) ? (int)$input['reserva_id'] : 0;

if (!$token && $reserva_id <= 0) {
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'token ou reserva_id obrigatório']);
    exit;
}

try {
    if ($token) {
        $row = $pdo->query("SHOW COLUMNS FROM reservas LIKE 'payment_token'")->fetch();
        if ($row) {
            $q = $pdo->prepare("SELECT * FROM reservas WHERE payment_token = :t LIMIT 1");
            $q->execute([':t'=>$token]);
            $reserva = $q->fetch();
        } else {
            $tmp = sys_get_temp_dir() . "/viajante_payment_tokens.json";
            $reserva = null;
            if (file_exists($tmp)) {
                $store = json_decode(file_get_contents($tmp), true) ?: [];
                if (isset($store[$token])) {
                    $reserva = ['id' => (int)$store[$token]['reserva_id']];
                }
            }
        }
    } else {
        $q = $pdo->prepare("SELECT * FROM reservas WHERE id = :id LIMIT 1");
        $q->execute([':id' => $reserva_id]);
        $reserva = $q->fetch();
    }

    if (!$reserva) {
        http_response_code(404);
        echo json_encode(['success'=>false,'message'=>'Reserva não encontrada pelo token/reserva_id']);
        exit;
    }

    $id = (int)$reserva['id'];

    $payment_reference = 'SIMUL-' . bin2hex(random_bytes(6));
    $u = $pdo->prepare("UPDATE reservas SET status = :status, updated_at = NOW() WHERE id = :id");
    $u->execute([':status' => 'Pago', ':id' => $id]);

    $col = $pdo->query("SHOW COLUMNS FROM reservas LIKE 'payment_reference'")->fetch();
    if ($col) {
        $up = $pdo->prepare("UPDATE reservas SET payment_reference = :p WHERE id = :id");
        $up->execute([':p' => $payment_reference, ':id' => $id]);
    }

    echo json_encode(['success'=>true,'message'=>'Pagamento confirmado','reserva_id'=>$id,'payment_reference'=>$payment_reference]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
