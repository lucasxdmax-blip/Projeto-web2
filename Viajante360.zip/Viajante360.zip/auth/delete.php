<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'Método não permitido']);
    exit;
}

if (empty($_SESSION['user']['id'])) {
    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'Usuário não autenticado.']);
    exit;
}

$userId = (int) $_SESSION['user']['id'];

try {
    $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
    $stmt->execute([$userId]);

    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']
        );
    }
    session_destroy();

    echo json_encode(['success'=>true,'message'=>'Conta excluída com sucesso']);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    @file_put_contents(__DIR__ . '/debug.log', '['.date('c')."] delete error: ".$e->getMessage()."\n", FILE_APPEND);
    echo json_encode(['success'=>false,'message'=>'Erro interno no servidor.']);
    exit;
}
