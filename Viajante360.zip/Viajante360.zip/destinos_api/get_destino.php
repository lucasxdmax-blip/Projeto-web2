<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID inválido.']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, titulo, descricao, preco, localizacao, imagem, disponivel, created_at, updated_at FROM destinos WHERE id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();

if (!$row) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Destino não encontrado.']);
} else {
    echo json_encode(['success' => true, 'data' => $row]);
}
